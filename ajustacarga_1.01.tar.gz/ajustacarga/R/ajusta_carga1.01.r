#' @title Programa AJUSTACARGA
#' @name AJUSTACARGA
#'
#' @description Remove efeito de feriados e temperatura
#' 
#' @param (arqcarga,arqtemp,arqferiado,arqverao)
#' 
#' @details 
#'
#'
#' @return serie de carga ajustada
#'
#' @author CEPEL
#'
#'
#'
#' @export 
AJUSTACARGA <-function(sessionUI,DADOS,periodo,lags,tipodiario,abatecarga) {

			#save(DADOS,periodo,lags,tipodiario,abatecarga,file='entradaajusta.Rdata')
            # arqcarga=paste(caminho,"/",arqcarga,sep="")
            # arqtemp=paste(caminho,"/",arqtemp,sep="")
            # arqferiado=paste(caminho,"/",arqferiado,sep="")
            # arqverao=paste(caminho,"/",arqverao,sep="")
            # DADOS=LEITORA(sessionUI,arqcarga,arqtemp,arqferiado,arqverao) # leitura arquivo de dados em formato csv
			
			#DADOS$DATAHIST=DADOS$DATAHIST[(which(rownames(DADOS$DATAHIST)==periodo[1]):which(rownames(DADOS$DATAHIST)==periodo[2])),]
			if (tipodiario==0)DADOS$DATAHIST=DADOS$DATAHIST_FILTRADOS[(which(rownames(DADOS$DATAHIST_FILTRADOS)==periodo[1]):which(rownames(DADOS$DATAHIST_FILTRADOS)==periodo[2])),]
			if (tipodiario==1) DADOS$DATAHIST=DADOS$DATAHIST_FILTRADOS[(which(rownames(DADOS$DATAHIST_FILTRADOS)==periodo[1]):which(rownames(DADOS$DATAHIST_FILTRADOS)==periodo[2])),]
			
			ind=tail(which((as.numeric(substr(abatecarga[,1],6,7))==month(tail(rownames(DADOS$DATAHIST),1)))),1)
			abatecarga=abatecarga[1:ind,]
			
			precipitacao=DADOS_FILTRADOS$PRECIPITACAO
			serieprecipitacao=0
			#if (sum(precipitacao>0)) if (as.Date(periodo[1])>=as.Date(precipitacao[1,1])) serieprecipitacao=precipitacao[(which(as.Date(precipitacao[,1])==periodo[1])):(which(as.Date(precipitacao[,1])==periodo[2])),]
			if (sum(precipitacao>0)) if ((as.Date(periodo[1])>=precipitacao[1,1])&(as.Date(periodo[2])<=precipitacao[nrow(precipitacao),1])) serieprecipitacao=precipitacao[(which(as.Date(precipitacao[,1])==periodo[1])):(which(as.Date(precipitacao[,1])==periodo[2])),]

			ano=as.numeric(substr(rownames(DADOS$DATAHIST),1,4)) # a
      mes=as.numeric(substr(rownames(DADOS$DATAHIST),6,7)) # m
      dia=as.numeric(substr(rownames(DADOS$DATAHIST),9,10)) # d
      diasemana=weekdays(as.Date(rownames(DADOS$DATAHIST))) # r
      diasemana=as.POSIXlt(as.Date(rownames(DADOS$DATAHIST)))$wday+1 # 1 domingo			

	  ####################################### 
      # ajusta carga pelo efeito calendario #
      #######################################
	  printUI(sessionUI, paste("Metodo empirico: ajustando carga livre do efeito feriado..."))				
      # calcula pesos para cada dia 
      indicesemi=which(diasemana==1)
      indicesemf=indicesemi-1
      indicesemi=indicesemi[-length(indicesemi)] # inicios das semanas ou domingos
      indicesemf=indicesemf[-1] # fins de semana ou sabados
      numsemanas=length(indicesemi) # numero de semanas completas            
			
			if (tipodiario==0) {
			   indcarga=c(1:24)
			   indferiado=25
			   indverao=26
			   indtemp=c(27:50)
			}
			if (tipodiario==1){
			   indcarga=1
			   indferiado=2
			   indverao=3
			   indtemp=4
			} 
			
      pesos=c()
      carga=DADOS$DATAHIST[indicesemi[1]:indicesemf[numsemanas],indcarga] # carga			
      if (tipodiario==0) cargadia=apply(carga,1,mean)
	  if (tipodiario==1) cargadia=carga
	  diasemana1=diasemana[indicesemi[1]:indicesemf[numsemanas]]
      mes1=mes[indicesemi[1]:indicesemf[numsemanas]]
      ano1=ano[indicesemi[1]:indicesemf[numsemanas]]
      feriados=DADOS$DATAHIST[indicesemi[1]:indicesemf[numsemanas],indferiado]
      verao=DADOS$DATAHIST[indicesemi[1]:indicesemf[numsemanas],indverao]
      for (i in 1:numsemanas) {
		    # percorre semanas completas    
            if (sum(DADOS$DATAHIST[indicesemi[i]:indicesemf[i],indferiado])==0) {
              if (tipodiario==0) mediacargasemana=mean(apply(DADOS$DATAHIST[indicesemi[i]:indicesemf[i],indcarga],2,mean))
			     if (tipodiario==1) mediacargasemana=mean(DADOS$DATAHIST[indicesemi[i]:indicesemf[i],indcarga])
	             # semana normal ou tipo 1 
                 for (j in indicesemi[i]:indicesemf[i]) {        
                    if (tipodiario==0) pesos=c(pesos,apply(DADOS$DATAHIST[j,indcarga],1,mean)/mediacargasemana)
				    if (tipodiario==1) pesos=c(pesos,DADOS$DATAHIST[j,indcarga]/mediacargasemana)
                } 
              } else {
                # semana com feriado ou tipo 2
                iflag=0
                delta=1
                while(iflag==0) {
                    semananterior=i-delta
                    semanaposterior=i+delta
                    if (semananterior>0 & semanaposterior<=numsemanas){
                        chave1=0
                        chave2=0
                        if (sum(DADOS$DATAHIST[indicesemi[semananterior]:indicesemf[semananterior],indferiado])==0) chave1=1              
                        if (sum(DADOS$DATAHIST[indicesemi[semanaposterior]:indicesemf[semanaposterior],indferiado])==0) chave2=1
                        if (chave1==1 & chave2==1) iflag=1
                        mediacargasemana=apply(rbind(DADOS$DATAHIST[indicesemi[semananterior]:indicesemf[semananterior],indcarga],DADOS$DATAHIST[indicesemi[semanaposterior]:indicesemf[semanaposterior],indcarga]),2,mean)
                        mediacargasemana=mean(mediacargasemana)  
                    } else { 
                        if (semanaposterior<=numsemanas){
                            chave1=1
                            chave2=0
                            if (sum(DADOS$DATAHIST[indicesemi[semanaposterior]:indicesemf[semanaposterior],indferiado])==0) chave2=1
                            if (chave1==1 & chave2==1) iflag=1
                            if (tipodiario==0){
					             				 mediacargasemana=apply(DADOS$DATAHIST[indicesemi[semanaposterior]:indicesemf[semanaposterior],indcarga],2,mean)
									             mediacargasemana=mean(mediacargasemana)  
								            }else{
									             mediacargasemana=mean(DADOS$DATAHIST[indicesemi[semanaposterior]:indicesemf[semanaposterior],indcarga])
								            }
							          } else {
                            if (semananterior>0){
                                chave1=0
                                chave2=1
                                if (sum(DADOS$DATAHIST[indicesemi[semananterior]:indicesemf[semananterior],indferiado])==0) chave1=1
                                if (chave1==1 & chave2==1) iflag=1
                                if (tipodiario==0){
									                  mediacargasemana=apply(DADOS$DATAHIST[indicesemi[semananterior]:indicesemf[semananterior],indcarga],2,mean)
                                    mediacargasemana=mean(mediacargasemana)  
									              }else{
										               mediacargasemana=mean(DADOS$DATAHIST[indicesemi[semananterior]:indicesemf[semananterior],indcarga])
									              }
								            }
                        }
							
                    }      
                    delta=delta+1
                }
                # semana tipo 2
                for (j in indicesemi[i]:indicesemf[i]) {        
                  if (tipodiario==0) pesos=c(pesos,apply(DADOS$DATAHIST[j,indcarga],1,mean)/mediacargasemana)
				  if (tipodiario==1) pesos=c(pesos,DADOS$DATAHIST[j,indcarga]/mediacargasemana)
					
                }
            }
      }

      # calcula carga adj
      if (tipodiario==0) cargadia2=apply(DADOS$DATAHIST[,indcarga],1,mean)
			if (tipodiario==1) cargadia2=DADOS$DATAHIST[,1]
			
      # calcula peso tipico
      seriepesotipico=0*cargadia2
      for (i in 1:7) {
        indice2020=which(diasemana1==i & (feriados==0 | feriados>6 | feriados!=12))
        seriepesotipico[which(diasemana==i)]=quantile(pesos[indice2020],0.5)
        if (i==1) pesodomingo=mean(pesos[indice2020])
      }
      
      # pesos dos dias de feriados
      indice2020=which(DADOS$DATAHIST[,indferiado]>=1 & DADOS$DATAHIST[,indferiado]<=6)
      seriepesotipico[indice2020]=pesodomingo
      #seriepesotipico[indice2020]=mean(pesos[auxindice2020])
      #seriepesotipico[indice2020]=quantile(pesos[auxindice2020],0.5)
      cargaadj=cargadia2/seriepesotipico
      
      # dead week
      pesodeadweek=c()
      anopesodeadweek=c()
      for (i in min(ano):max(ano)){
          indicedeadweek=which(ano==i & mes==12 & (dia>=26 & dia<=30)) # periodo entre natal e ano novo
          if (length(indicedeadweek)>0){
             aux=sum((pesos[indicedeadweek]/seriepesotipico[indicedeadweek])-1)/5
            if(is.na(aux)){
               indicedeadweek=which(ano==i-1 & mes==12 & (dia>=26 & dia<=30)) # periodo entre natal e ano novo
               aux=sum((pesos[indicedeadweek]/seriepesotipico[indicedeadweek])-1)/5
             }
             pesodeadweek=c(pesodeadweek,aux)
             cargaadj[indicedeadweek]=cargaadj[indicedeadweek]/(1-aux)
          }else{
            pesodeadweek=c(pesodeadweek,0)
          }
          anopesodeadweek=c(anopesodeadweek,i)
      }

      ###calcula o efeito da carga ajustada
      serieefeitof=cargadia2-cargaadj
      efeitof=c()
      for (i in 1:11){
          ind=which(DADOS$DATAHIST$feriado==i)
          efeitof=c(efeitof,mean(serieefeitof[i]))
      }
			
	  # monta serie media mensal livre de efeito calendario
      cargamensaladj=c()
      cargamensalobs=c()
      for (iano in min(ano1):max(ano1)){
          for (imes in 1:12){
                #aux=which(ano1==iano & mes1==imes) 
      			aux1=which((month(rownames(DADOS$DATAHIST))==imes)&(year(rownames(DADOS$DATAHIST))==iano))
				if (length(aux1)>0) {
                   cargamensaladj=c(cargamensaladj,mean(cargaadj[aux1]))
                   serieaux=DADOS$DATAHIST[aux1,indcarga]
                   if (tipodiario==0) serieaux=apply(serieaux,1,mean)
                   cargamensalobs=c(cargamensalobs,mean(serieaux))
                }   
          }
      }


	  ######################################## 
      # ajusta carga pelo efeito temperatura #
      ########################################
			printUI(sessionUI, paste("Metodo empirico: ajustando carga livre do efeito temperatura..."))			
            
			y=ts(cargaadj,start=as.Date(rownames(DADOS$DATAHIST)[1]),frequency=365)
			names(y)=seq(as.Date(rownames(DADOS$DATAHIST)[1]),as.Date(rownames(DADOS$DATAHIST)[length(y)]),by='day')
			media<-function(x) mean(x,na.rm = T)
            if (tipodiario==0) tempdia=apply(DADOS$DATAHIST[,27:50],1,media) # temperatura
			if (tipodiario==1) tempdia=DADOS$DATAHIST[,4]# temperatura
			
			mes=as.numeric(substr(names(y),6,7))
			for (i in 1:12) {
			    tempdia[which(mes==i)]=tempdia[which(mes==i)]-mean(tempdia[which(mes==i)])
			}
			x=ts(tempdia,start=as.Date(rownames(DADOS$DATAHIST)[1]),frequency=365)
			names(x)=seq(as.Date(rownames(DADOS$DATAHIST)[1]),as.Date(rownames(DADOS$DATAHIST)[length(x)]),by='day') 			

			equacao=paste0('y~L(y,1)')
			for (kk in 2:lags[1]) equacao=paste0(equacao,'+L(y,',kk,')')
			equacao=paste0(equacao,'+x') # inclui efeito temperatura sem defasagem
			#if (lags[2]>1) for (kk in 1:lags[2]) equacao=paste0(equacao,'+L(x,',kk,')')

			modelo=dynlm(eval(parse(text = equacao)))
			modelo=step(modelo,trace=0,direction="backward",scope=list(lower=~x)) # regressao stepwise

			chavearima=0 # 0 nao faz arima
			if (chavearima==1){
  			  # MODELO AUTO.ARIMA
			    mm=model.matrix(~x-1,data=data.frame(x,y))
			    fit <- auto.arima(y=y,xreg=mm,max.p=7,max.q=1,max.d=1,max.order=7,seasonal=F,stepwise=T)
			    print(fit)
			    nomescoeffit=names(coef(fit))
			    efeitotempaa=coef(fit)[which(nomescoeffit=="x")]
			    print(efeitotempaa)
			    #aux=unlist(strsplit(names(coef(fit))[1],"ar"))
			    #maxlagsaa=max(as.numeric(aux[seq(2,length(aux),2)]))+1
  			  xreg=c()
	  		  y1=c()	
		  	  nomes=c()			
			    maxlagsaa=1
			    for (i in maxlagsaa:length(y)) {
			        y1=c(y1,y[i])
			        if (length(which(nomescoeffit=="x"))>0){
			           xreg=rbind(xreg,x[i])
			        }else{
			           xreg=c(xreg,x[i])
			        }
			        nomes=c(nomes,names(y)[i])
			    }			
			    if (length(which(nomescoeffit=="x"))>0){
			       efeitotemp=xreg%*%efeitotempaa
			    } else {
			       efeitotemp=xreg*0 # sem efeito temperatura
			    }
			    cargaadjTarima=y1-efeitotemp
			    names(cargaadjTarima)=nomes
			    # FIM DA MODELAGEM ARIMA
			}
			
			#if (length(which(substr(names(coef(modelo)),3,3)=="y"))>0) {
 			#   # entra aqui se lags da carga aparecem no modelo stepwise
 			#   posic=which(substr(names(coef(modelo)),3,3)=="y")
			#   listalags=unlist(strsplit(names(coef(modelo)[posic])," "))
			#   lagsc=as.numeric(unlist(strsplit(listalags[seq(2,length(listalags),2)],")")))
			#   maxlags=max(lagsc)
			#} else {
			#   lagsc=NULL # valores passados da carga nao entram no modelo stepwise
			#   maxlags=0
			#}

			iniccoef=which(names(coef(modelo))=="x") # posicao de x, o primeiro coeficiente da temperatura lag 0
			if (length(which(substr(names(coef(modelo)),3,3)=="x"))>0 | length(iniccoef)>0) {
			   # entra aqui se variavel temperatura incluida no modelo stepwise
  			 if (length(iniccoef)>0) {
 			      # entra aqui se temperatura lag=0 aparece no modelo stepwise
 			      coeftemp=coef(modelo)[iniccoef:length(coef(modelo))] # coeficientes da temperatura
 			      #if (length(coeftemp)>1){
   			    #    listalags=unlist(strsplit(names(coef(modelo)[iniccoef:length(coef(modelo))])," ")) # lags temperatura
   			    #    lagst=as.numeric(unlist(strsplit(listalags[seq(3,length(listalags),2)],")")))
   			    #    lagst=c(0,lagst)
 			      #} else {
 			          lagst=0
 			      #}
 			      #} else {
 			      # entra aqui se temperatura lag=0 nao aparece no modelo stepwise
 			      #posic=which(substr(names(coef(modelo)),3,3)=="x")
 			      #coeftemp=coef(modelo)[posic] # coeficientes da temperatura
 			      #listalags=unlist(strsplit(names(coef(modelo)[posic])," "))
 			      #lagst=as.numeric(unlist(strsplit(listalags[seq(2,length(listalags),2)],")")))
 			   }
 			   #maxlags=max(maxlags,lagst)+1
			}else{
			   lagst=NULL # entra aqui se temperatura nao foi incluida no modelo stepwise
			   #maxlags=max(maxlags)+1
			}

			xreg=c()
      y1=c()	
      nomes=c()			
      maxlags=1
			for (i in maxlags:length(y)) {
			     y1=c(y1,y[i])
			     if (length(lagst)>0){
  			       xreg=rbind(xreg,x[i-lagst])
			     }else{
			         xreg=c(xreg,x[i])
			     }
				   nomes=c(nomes,names(y)[i])
		  }			
      if (length(lagst)>0){
          #coeftemp=coef(modelo)[-c(1:(iniccoef-1))]
          efeitotemp=xreg%*%coeftemp
      } else {
          efeitotemp=xreg*0 # sem efeito temperatura
      }
			cargaadjT=y1-efeitotemp
			names(cargaadjT)=nomes
			if (chavearima==1) cargaadjT=cargaadjTarima
			
			# carga ajustada temperatura mensal
			ano=as.numeric(substr(nomes,1,4))
			mes=as.numeric(substr(nomes,6,7))
			serie=c()
			for (i in min(ano):max(ano)) {
			    for (j in 1:12) {
				    indice=which (mes==j & ano==i)
					if (length(indice)>0)serie=c(serie,mean(cargaadjT[indice]))
				}
			}
			cargadjT_mensal=serie

			#y0=ts(DADOS$DATAHIST[,1],start=as.Date(rownames(DADOS$DATAHIST)[1]),frequency=7)
			#write.csv(data.frame(y,x),"DSAempT.csv") # dados para conferencia
			
	  ######################################### 
      # ajusta carga pelo efeito PRECIPITACAO #
      #########################################
			cargaadjP_mensal=rep(0,length(cargadjT_mensal))
			modelo2=0
			if (length(serieprecipitacao)>1){
				printUI(sessionUI, paste("Metodo empirico: ajustando carga livre do efeito precipitacao..."))			
				
				y=ts(as.numeric(cargaadj),start=as.Date(rownames(DADOS$DATAHIST)[1]),frequency=365)
				names(y)=seq(as.Date(rownames(DADOS$DATAHIST)[1]),as.Date(rownames(DADOS$DATAHIST)[length(y)]),by='day')
				media<-function(x) mean(x,na.rm = T)
				if (tipodiario==0) tempdia=apply(DADOS$DATAHIST[,27:50],1,media) # temperatura
				if (tipodiario==1) tempdia=DADOS$DATAHIST[,4]# temperatura

				mes=as.numeric(substr(names(y),6,7))
				for (i in 1:12) {
				  tempdia[which(mes==i)]=tempdia[which(mes==i)]-mean(tempdia[which(mes==i)])
				}
				x=ts(tempdia,start=as.Date(rownames(DADOS$DATAHIST)[1]),frequency=365)
				names(x)=seq(as.Date(rownames(DADOS$DATAHIST)[1]),as.Date(rownames(DADOS$DATAHIST)[length(x)]),by='day') 			
				
				mes=as.numeric(substr(serieprecipitacao[,1],6,7))
				#mes=as.numeric(substr(names(y),6,7))
				for (i in 1:12) {
				  serieprecipitacao[which(mes==i),2]=serieprecipitacao[which(mes==i),2]-mean(serieprecipitacao[which(mes==i),2])
				}

				z=ts(serieprecipitacao[,2],start=as.Date(rownames(DADOS$DATAHIST)[1]),frequency=365)
				names(z)=seq(as.Date(rownames(DADOS$DATAHIST)[1]),as.Date(rownames(DADOS$DATAHIST)[length(x)]),by='day') 			

				write.csv(data.frame(y1,x,z),"DSAemp.csv") # dados para conferencia
				
				equacao=paste0('y~L(y,1)')
				for (kk in 2:lags[1]) equacao=paste0(equacao,'+L(y,',kk,')')
				equacao=paste0(equacao,'+x') # efeito temperatura sem defasagem
				#for (kk in 1 : lags[2]) equacao=paste0(equacao,'+L(x,',kk,')')
				equacao=paste0(equacao,'+z') # efeito precipitacao sem defasagem
				#for (kk in 1:lags[3]) equacao=paste0(equacao,'+L(z,',kk,')')

				modelo2=dynlm(eval(parse(text = equacao)))
				modelo2=step(modelo2,trace=0,direction="backward",scope=list(lower=~x+z)) # regressao stepwise
								
				#mm=model.matrix(~x+z-1,data=data.frame(x,z,y))
				#fit <- auto.arima(y=y,xreg=mm,max.p=7,max.q=0,d=0,max.order=7,seasonal=F,stepwise=T)
				#nomescoeffit=names(coef(fit))
				#efeitotempaa=coef(fit)[which(nomescoeffit=="x")]*x
				#efeitoprecipaa=coef(fit)[which(nomescoeffit=="z")]*z
				
				#if (length(which(substr(names(coef(modelo2)),3,3)=="y"))>0) {
				#  # entra aqui se lags da carga aparecem no modelo stepwise
				#  posic=which(substr(names(coef(modelo2)),3,3)=="y")
				#  listalags=unlist(strsplit(names(coef(modelo2)[posic])," "))
				#  lagsc=as.numeric(unlist(strsplit(listalags[seq(2,length(listalags),2)],")")))
				#  maxlags=max(lagsc)
				#} else {
				#  lagsc=NULL # valores passados da carga nao entram no modelo stepwise
				#  maxlags=0
				#}
				
				inictempcoef=which(names(coef(modelo2))=="x") # posicao de x, o primeiro coeficiente da temperatura lag=0
				if (length(which(substr(names(coef(modelo2)),3,3)=="x"))>0 | length(inictempcoef)>0) {
				   # entra aqui se variavel temperatura incluida no modelo stepwise
				   if (length(inictempcoef)>0) {
				     # entra aqui se temperatura lag=0 aparece no modelo stepwise
				     aux=inictempcoef+length(which(substr(names(coef(modelo2)),3,3)=="x"))
				     coeftemp=coef(modelo2)[inictempcoef:aux] # coeficientes da temperatura
				     #if (length(which(substr(names(coef(modelo2)),3,3)=="x"))>0){
				     # listalags=unlist(strsplit(names(coef(modelo2)[inictempcoef:aux])," ")) # lags temperatura
				     # lagst=as.numeric(unlist(strsplit(listalags[seq(3,length(listalags),2)],")")))
				     # lagst=c(0,lagst)
				     #} else {
				       lagst=0
				     #}
				   #} else {
				     # entra aqui se temperatura lag=0 nao aparece no modelo stepwise
				     # posic=which(substr(names(coef(modelo2)),3,3)=="x")
				     # coeftemp=coef(modelo2)[posic] # coeficientes da temperatura
				     # listalags=unlist(strsplit(names(coef(modelo2)[posic])," "))
				     # lagst=as.numeric(unlist(strsplit(listalags[seq(2,length(listalags),2)],")")))
				   }
				   #maxlags=max(maxlags,lagst)
				}else{
				   lagst=NULL # entra aqui se temperatura nao foi incluida no modelo stepwise
				   #maxlags=max(maxlags)
				}
				
				inicprecipitacoef=which(names(coef(modelo2))=="z") # posicao de z, o primeiro coeficiente da precipitacao lag=0
				if (length(which(substr(names(coef(modelo2)),3,3)=="z"))>0 | length(inicprecipitacoef)>0) {
				  # entra aqui se variavel precipitacao incluida no modelo stepwise
				  if (length(inicprecipitacoef)>0) {
				    # entra aqui se precipitacao lag=0 aparece no modelo stepwise
				    aux=inicprecipitacoef+length(which(substr(names(coef(modelo2)),3,3)=="z"))
				    coefprec=coef(modelo2)[inicprecipitacoef:aux] # coeficientes da precipitacao
				    #if (length(which(substr(names(coef(modelo2)),3,3)=="z"))>0){
  	 			    #     listalags=unlist(strsplit(names(coef(modelo2)[inicprecipitacoef:aux])," ")) # lags precipitacao
		  		    #    lagsp=as.numeric(unlist(strsplit(listalags[seq(3,length(listalags),2)],")")))
				    #    lagsp=c(0,lagsp)
				    #} else{
				      lagsp=0
				    #}
				  #} else {
				    # entra aqui se precipitacao lag=0 nao aparece no modelo stepwise
				    #posic=which(substr(names(coef(modelo2)),3,3)=="z")
				    #coefprec=coef(modelo2)[posic] # coeficientes da precipitacao
				    #listalags=unlist(strsplit(names(coef(modelo2)[posic])," "))
				    #lagsp=as.numeric(unlist(strsplit(listalags[seq(2,length(listalags),2)],")")))
				  }
				  #maxlags=max(maxlags,lagsp)+1
				}else{
				  lagsp=NULL # entra aqui se precipitacao nao foi incluida no modelo stepwise
				  #if (maxlags==0) maxlags=max(maxlags)+1
				}
				
				#listalags=unlist(strsplit(names(coef(modelo2)[1:(inictempcoef-1)])," "))
				#lagsc=as.numeric(unlist(strsplit(listalags[seq(3,length(listalags),2)],")")))
				#listalags=unlist(strsplit(names(coef(modelo2)[inictempcoef:(inicprecipitacoef-1)])," "))
				#lagst=as.numeric(unlist(strsplit(listalags[seq(3,length(listalags),2)],")")))
				#listalags=unlist(strsplit(names(coef(modelo2)[inicprecipitacoef:length(coef(modelo2))])," "))
				#lagsp=as.numeric(unlist(strsplit(listalags[seq(3,length(listalags),2)],")")))
				#lagst=c(0,lagst)
				#lagsp=c(0,lagsp)
				##lagsc=seq(1,lags[1],1)
				##lagst=seq(0,lags[2],1)
				##lagsp=seq(0,lags[3],1)
				##maxlags=max(lagsc,lagst,lagsp)+1

                chavearima=0
				if (chavearima==1){
				    # MODELO AUTO.ARIMA
				    mm=model.matrix(~z-1,data=data.frame(z,y))
				    #mm=model.matrix(~x+z-1,data=data.frame(x,z,y))
				    fit <- auto.arima(y=y,xreg=mm,max.p=7,max.q=1,max.d=1,max.order=7,seasonal=F,stepwise=T)
				    #print(fit)
				    nomescoeffit=names(coef(fit))
  				    #efeitotempaa=coef(fit)[which(nomescoeffit=="x")]
	  			    efeitoprecipaa=as.numeric(coef(fit)[which(nomescoeffit=="z")])
	  			    print(efeitoprecipaa)
		  		    aux=unlist(strsplit(names(coef(fit))[1],"ar"))
			  	    maxlagsaa=max(as.numeric(aux[seq(2,length(aux),2)]))+1
   				    maxlagsaa=1
  				    #xreg=c()
	  			    y1=c()	
		  		    #nomes=c()			
		  		    for (i in maxlagsaa:length(y)) {
  	  			        y1=c(y1,y[i])
    				    #  if (length(which(nomescoeffit=="x"))>0){
    				    #    xreg=rbind(xreg,x[i])
     				    #  }else{
		    		    #    xreg=c(xreg,x[i])
    				    #  }
		    		    nomes=c(nomes,names(y)[i])
				    }			
				    #if (length(which(nomescoeffit=="x"))>0){
				    #  efeitotemp=xreg%*%efeitotempaa
				    #} else {
				    #  efeitotemp=xreg*0 # sem efeito temperatura
				    #}
				    xreg=c()
				    nomes=c()			
				    for (i in maxlagsaa:length(y)) {
				        if (length(which(nomescoeffit=="z"))>0){
				          xreg=rbind(xreg,z[i])
				        }else{
				          xreg=c(xreg,z[i])
				        }
				        nomes=c(nomes,names(y)[i])
				    }	
				  
				    if (length(which(nomescoeffit=="z"))>0){
				       efeitoprec=xreg%*%efeitoprecipaa
				    } else {
				       efeitoprec=xreg*0 # sem efeito precipitacao
				    }
				    #cargaadjParima=y1-efeitotemp-efeitoprec
				    cargaadjParima=y1+efeitoprec
				    # FIM DA MODELAGEM ARIMA
				}
				
				xreg=c()
				y1=c()	
				nomes=c()			
				maxlags=1
				for (i in maxlags:length(y)) {
					 y1=c(y1,y[i])
					 if (length(lagsp)>0){
   			  	   	     xreg=rbind(xreg,z[i-(lagsp)])
					 }else{
					     xreg=c(xreg,z[i])
					 }
					 nomes=c(nomes,names(y)[i])
				}
				if (length(lagsp)>0){
				  efeitoprec=xreg%*%coefprec
				} else {
				  efeitoprec=xreg*0 # sem efeito precipitacao
				}

				xreg=c()
				y1=c()	
				nomes=c()			
				for (i in maxlags:length(y)) {
				    y1=c(y1,y[i])				    
				    if (length(lagst)>0){
				       xreg=rbind(xreg,x[i-(lagst)])
				    }else{
				       xreg=c(xreg,x[i])
				    }
				    nomes=c(nomes,names(y)[i])
				}
				if (length(lagst)>0){
				   efeitotemp=xreg%*%coeftemp
				} else {
				  efeitotemp=xreg*0 # sem efeito temperatura
				}

				#coeftemp=coef(modelo2)[-c(1:(lags[1]+1))]
				#coeftemp=coeftemp[-c((lags[2]+2):length(coeftemp))]
				#coeftemp=coef(modelo2)[inictempcoef:(inicprecipitacoef-1)]
				#efeitotemp=xreg%*%coeftemp
				
				cargaadjP=y1-efeitoprec-efeitotemp
				#cargaadjP=y1-efeitoprec
				names(cargaadjP)=nomes
				if (chavearima==1) cargaadjP=cargaadjParima

				# carga ajustada precipitacao mensal
				ano=as.numeric(substr(nomes,1,4))
				# mes=as.numeric(substr(nomes,6,7))
				serie=c()
				for (i in min(ano):max(ano)) {
					for (j in 1:12) {
						indice=which (mes==j & ano==i)
						if (length(indice)>0)serie=c(serie,mean(cargaadjP[indice]))
					}
				}
				cargaadjP_mensal=serie
			}
			
			meses=unique(substr(rownames(DADOS$DATAHIST[indicesemi[1]:indicesemf[numsemanas],]),1,7))
			tipoferiado=sort(unique(DADOS$DATAHIST$feriado))
			
# 			
# 			cargaadjP_mensalabate=0
# 			if ((sum(abatecarga>0))){
#   			 if((abatecarga[1,1]<=meses[1])&(abatecarga[nrow(abatecarga),1]>=meses[length(meses)])){
#   				abatecarga=	abatecarga[(which(abatecarga[,1]==meses[1])):(which(abatecarga[,1]==meses[length(meses)])),2]
#   				cargamensalobs=cargamensalobs-abatecarga
#   				cargamensaladj=cargamensaladj-abatecarga
#   				cargadjT_mensal=cargadjT_mensal-abatecarga
#   				if (sum(cargaadjP_mensal)>0) cargaadjP_mensal=cargaadjP_mensal-abatecarga
#   			}
# 			}
						
			cargamensaladjabate=rep(0,length(cargamensalobs))
			cargamensalobsabate=rep(0,length(cargamensalobs))
			if (length(abatecarga)>1){
			  if((abatecarga[1,1]<=meses[1])&(abatecarga[nrow(abatecarga),1]>=meses[length(meses)])){
			    abatecarga=	abatecarga[(which(abatecarga[,1]==meses[1])):(which(abatecarga[,1]==meses[length(meses)])),2]
			    cargamensalobsabate=cargamensalobs-abatecarga # carga liquida
			    cargamensaladjabate=cargadjT_mensal-abatecarga # carga ajustada calendario liquida
			    #cargamensalcalabate=cargamensalcal-abatecarga # carga ajustada calendario liquida
			    if (sum(cargaadjP_mensal)>0)cargamensaladjabate=cargaadjP_mensal-abatecarga
			  } 
			}else{
			  cargamensalobsabate=cargamensalobs # carga liquida
			  cargamensaladjabate=cargadjT_mensal # carga ajustada calendario liquida
			  if (sum(cargaadjP_mensal)>0)cargamensaladjabate=cargaadjP_mensal
			}
			      
			dfsaida=data.frame(cargamensalobs,cargamensaladj,cargadjT_mensal[1:length(cargamensalobs)],cargaadjP_mensal[1:length(cargamensalobs)],cargamensalobsabate[1:length(cargamensalobs)],cargamensaladjabate[1:length(cargamensalobs)])
			#save(dfsaida,file='dfsaida.Rdata')
			rownames(dfsaida)=unique(substr(rownames(DADOS$DATAHIST[indicesemi[1]:indicesemf[numsemanas],]),1,7))			
			colnames(dfsaida)=c("carga_obs","carga_adj_CAL","carga_adj_CAL_T","carga_adj_CAL_T_P","carga_obs_liq","carga_adj_liq")
      
			saida=list(SAIDA=dfsaida,PESOS_C=efeitof,MODELO_C_T=modelo,MODELO_C_T_P=modelo2,tempdia=tempdia)
			
			return(saida)
}


#' @title Programa LEITORA
#' @name LEITORA
#'
#' @description Realiza a a leitura dos dados em dataframe ou csv
#' 
#' @param (arqcarga,arqtemp,arqferiado,arqverao)
#' 
#' @details 
#'
#'
#' @return Matriz com os dados lidos
#'
#' @author CEPEL
#'
#'
#'
#' @export 
LEITORA=function(sessionUI,arqcarga,arqtemp,arqferiado,arqabatimento,arqprec){

#=====================================================================
# LEITURA DO ARQUIVO COM DADOS DE PERDAS PARA O ABATIMENTO DA SAIDA MENSAL
#=====================================================================
filename=arqabatimento
if (file.exists(filename)) {
    abatecarga=read.csv2(filename,stringsAsFactors=FALSE)
	printUI(sessionUI, paste("CONCLUIDA LEITURA DO ARQUIVO",filename))
} else {
    #printUI(sessionUI, paste("Alerta - Nao foi encontrado o arquivo com dados de abatimento de carga.",filename,sep=""))
	abatecarga=0
  
}

#=====================================================================
# LEITURA DO ARQUIVO COM DADOS DE PRECIPITACAO
#=====================================================================
filename=arqprec
if (file.exists(filename)) {
	precipitacao=read.csv2(filename,stringsAsFactors=FALSE,header=T)
	# ## CALCULA MEDIA DIARIA/PRECPITACAO
	# # MONTA SERIE MEDIA MENSAL A PARTIR DOS DADOS HORARIOS OBTIDOS NO NINJA
	# datasp=as.POSIXct(paste0(precipitacao[,3],"/",precipitacao[,2],"/",precipitacao[,1]," ",precipitacao[,4],":",precipitacao[,5]),format=' %d/%m/%Y %H:%M')
	# df1=data.frame(datas=datasp,prec=precipitacao[,6])
	# #  Convert to date if not already
	# #  Get days
	# df1$Day <- format(df1$datas,format="%d")
	# #  Get months
	# df1$Month <- format(df1$datas,format="%m")
	# #  Get years
	# df1$Year <- format(df1$datas,format="%Y")
	# #  Aggregate 'X2' on months and year and get mean
	# df1=aggregate( prec ~ Day + Month + Year , df1 , mean )
	# precipitacao=data.frame(datas=paste0(df1[,3],"-",df1[,2],"-",df1[,1]),precipitacao=df1[,4])
	precipitacao=data.frame(datas=precipitacao[,1],precipitacao=as.numeric(precipitacao[,2]))

	printUI(sessionUI, paste("CONCLUIDA LEITURA DO ARQUIVO",filename))
} else {
    #printUI(sessionUI, paste("Alerta - Nao foi encontrado o arquivo com dados de abatimento de carga.",filename,sep=""))
	precipitacao=0
  
}

#=====================================================================
# LEITURA DO ARQUIVO COM DADOS DE CARGA E MONTAGEM DA SERIE HISTORICA 
#=====================================================================
tipodiario=1
filename=arqcarga
if (file.exists(filename)) {
    dados=read.csv2(filename,stringsAsFactors=FALSE)
	if (dim(dados)[2]==6) tipodiario=0
} else {
    printUI(sessionUI, paste("Nao foi encontrado o arquivo com dados de carga ",filename,sep=""))
    stop("Execucao cancelada")
}
if (tipodiario==0){
		
	data_carga=paste(dados[,1],"-",dados[,2],"-",dados[,3],sep="") # vetor de datas yyyy-mm-dd
	indice=which(dados[,2]<=9 & dados[,3]<=9) 
	data_carga[indice]=paste(dados[indice,1],"-0",dados[indice,2],"-0",dados[indice,3],sep="")
	indice=which(dados[,2]<=9 & dados[,3]>9)
	data_carga[indice]=paste(dados[indice,1],"-0",dados[indice,2],"-",dados[indice,3],sep="")
	indice=which(dados[,2]>9 & dados[,3]<=9) 
	data_carga[indice]=paste(dados[indice,1],"-",dados[indice,2],"-0",dados[indice,3],sep="")
	# hora_carga=paste(dados[,4],":",dados[,5],sep="")
	carga=dados[,6] # coluna com dados de carga

	# gera sequencia de datas dos dias no historico
	data_inic_hist=data_carga[1]
	data_fim_hist=tail(data_carga,1)
	dias_historico=seq(as.Date(data_inic_hist), as.Date(data_fim_hist), "days") # datas dos perfis
	numdias=length(dias_historico) # numero de dias no historico com dados completos e incompletos

	# monta perfis diarios de carga
	perfis_carga=matrix(0,numdias,24) # inicializa matriz de perfis
	for (i in 1:numdias) {
		 indice=grep(dias_historico[i],data_carga,fixed=T) 
		 # procura data informada pelo ONS em dias_historico
		 if (length(indice)>0 & length(indice)<=24) {         
			 indicena=which(is.na(carga[indice]))
			 if (length(indicena)>0) carga[indice][indicena]=0.
			 colunas=dados[indice,4]
			 colunas=ifelse(colunas==0,24,colunas) # troca 0 por 24
			 perfis_carga[i,colunas]=carga[indice]
		 }
	}
	# a hora zero pertence ao dia anterior
	if (dados[1,4]==1) {
		# assume que arquivo comeca na hora 1
		# entra aqui se arquivo de carga comeca na hora 1
		matriz_perfis_carga=matrix(0,numdias,24) # inicializa matriz de perfis
		# hora zero pertence ao dia anterior
		matriz_perfis_carga[1:(numdias-1),24]=perfis_carga[2:numdias,24] 
		matriz_perfis_carga[,1:23]=perfis_carga[,1:23]
	} else {
		indicehora1=which(dados[,4]==1)[1]
		matriz_perfis_carga=matrix(0,numdias,24) # inicializa matriz de perfis
		# hora zero pertence ao dia anterior
		matriz_perfis_carga[1:(numdias-1),24]=perfis_carga[indicehora1:numdias,24] 
		matriz_perfis_carga[,1:23]=perfis_carga[,1:23]    
		# entra aqui se arquivo nao comeca na hora 1
		# stop("Arquivo com dados de carga nao comeca na hora 1")
	}
	rownames(matriz_perfis_carga)=as.character(dias_historico)
	# hora zero pertence ao dia anterior
	if(sum(tail(matriz_perfis_carga,1))==0) {
	   dias_historico=dias_historico[-numdias]
	   matriz_perfis_carga=matriz_perfis_carga[-numdias,]
	   numdias=numdias-1
	   data_fim_hist=tail(rownames(matriz_perfis_carga),1)
	}
	
	rm(dados)

	numdias=dim(matriz_perfis_carga)[1]
	dias_historico=dias_historico[1:numdias]
	
	printUI(sessionUI, paste("CONCLUIDA LEITURA DO ARQUIVO",filename))
	
	#=================================
	# LEITURA DO ARQUIVO COM FERIADOS 
	#=================================
	filename=arqferiado
	if (file.exists(filename)) {
		dados=read.csv2(filename,stringsAsFactors=FALSE)
	} else {
		printUI(sessionUI, paste("Nao foi encontrado o arquivo com dados de feriados ",filename,sep=""))
		stop("Execucao cancelada")
	}
	data_feriados=paste(dados[,1],"-",dados[,2],"-",dados[,3],sep="")
	indice=which(dados[,2]<=9 & dados[,3]<=9) 
	data_feriados[indice]=paste(dados[indice,1],"-0",dados[indice,2],"-0",dados[indice,3],sep="")
	indice=which(dados[,2]<=9 & dados[,3]>9)
	data_feriados[indice]=paste(dados[indice,1],"-0",dados[indice,2],"-",dados[indice,3],sep="")
	indice=which(dados[,2]>9 & dados[,3]<=9) 
	data_feriados[indice]=paste(dados[indice,1],"-",dados[indice,2],"-0",dados[indice,3],sep="")

	if (tipodiario==0) x_feriados=rep(0,dim(matriz_perfis_carga)[1])
	if (tipodiario==1) x_feriados=rep(0,dim(seriecarga)[1])

	numferiados=length(data_feriados)
	for (i in 1:numferiados) {
		 indice=grep(data_feriados[i],dias_historico)
		 x_feriados[indice]=dados[i,4]
	}
	rm(dados)
	printUI(sessionUI, paste("CONCLUIDA LEITURA DO ARQUIVO",filename))
	
	
}else{

	seriecarga=cbind(dados[,2])
	rownames(seriecarga)=dados[,1]
	
	numdias=dim(seriecarga)[1]
	dias_historico=dados[,1]
	rm(dados)
	
	printUI(sessionUI, paste("CONCLUIDA LEITURA DO ARQUIVO",filename))
	
	#=================================
	# LEITURA DO ARQUIVO COM FERIADOS 
	#=================================
	filename=arqferiado
	if (file.exists(filename)) {
		dados=read.csv2(filename,stringsAsFactors=FALSE)
		
		data_feriados=dados[,1]
		numferiados=length(data_feriados)
		x_feriados=rep(0,dim(seriecarga)[1])
		for (i in 1:numferiados) {
		 indice=grep(data_feriados[i],dias_historico)
		 x_feriados[indice]=dados[i,2]
	}
	rm(dados)
	printUI(sessionUI, paste("CONCLUIDA LEITURA DO ARQUIVO",filename))
		
	} else {
		printUI(sessionUI, paste("Nao foi encontrado o arquivo com dados de feriados ",filename,sep=""))
		stop("Execucao cancelada")
	}
	

}

#=========================================
# LEITURA DO ARQUIVO COM HORARIO DE VERAO 
#=========================================
# # NOME DO ARQUIVO COM DADOS DO HORARIO DE VERAO
# filename=arqverao
# if (file.exists(filename)) {
#     dados=read.csv2(filename,stringsAsFactors=FALSE)
# } else {
#     printUI(sessionUI, paste("Nao foi encontrado o arquivo com dados de horario de verao ",filename,sep=""))
#     stop("Execucao cancelada")
# }

dados=rbind(c('20/10/2013','16/02/2014'),
c('19/10/2014','22/02/2015'),
c('18/10/2015','21/02/2016'),
c('16/10/2016','19/02/2017'),
c('15/10/2017','18/02/2018'),
c('04/11/2018','17/02/2019'))

colnames(dados)=c('Data.inicial','Data.final')

nlinhas=dim(dados)[1]
if (tipodiario==0) x_verao=rep(0,dim(matriz_perfis_carga)[1])
if (tipodiario==1) x_verao=rep(0,dim(seriecarga)[1])

for (i in 1:nlinhas) {
    dia1=substr(dados[i,1],1,2)
    mes1=substr(dados[i,1],4,5)
    ano1=substr(dados[i,1],7,10)
    dia2=substr(dados[i,2],1,2)
    mes2=substr(dados[i,2],4,5)
    ano2=substr(dados[i,2],7,10)
    data1=as.Date(paste(ano1,"-",mes1,"-",dia1,sep=""))
    data2=as.Date(paste(ano2,"-",mes2,"-",dia2,sep=""))
    indice=which(dias_historico>data1 & dias_historico<data2)
    if (length(indice)>0) {
        x_verao[indice]=1
    }
}
#printUI(sessionUI, paste("CONCLUIDA LEITURA DO ARQUIVO",filename))
rm(dados)

#=============================================
# LEITURA DO ARQUIVO COM DADOS DE TEMPERATURA 
#=============================================

		filename=arqtemp
		if (file.exists(filename)) {
			dados=read.csv2(filename,stringsAsFactors=FALSE)
		} else {
			printUI(sessionUI, paste("Nao foi encontrado o arquivo com dados de temperatura ",filename,sep=""))
			stop("Execucao cancelada")
		}
		
		if (tipodiario==0){
		
		perfis_temperatura=matrix(0,numdias,24) # inicializa matriz de perfis
		data_temp=paste(dados[,1],"-",dados[,2],"-",dados[,3],sep="") # vetor de datas yyyy-mm-dd
		indice=which(dados[,2]<=9 & dados[,3]<=9) 
		data_temp[indice]=paste(dados[indice,1],"-0",dados[indice,2],"-0",dados[indice,3],sep="")
		indice=which(dados[,2]<=9 & dados[,3]>9)
		data_temp[indice]=paste(dados[indice,1],"-0",dados[indice,2],"-",dados[indice,3],sep="")
		indice=which(dados[,2]>9 & dados[,3]<=9) 
		data_temp[indice]=paste(dados[indice,1],"-",dados[indice,2],"-0",dados[indice,3],sep="")    
		for (i in 1:numdias) {
			 indice=grep(dias_historico[i],data_temp,fixed=T) # procura data informada pelo ONS em dias_historico
			 if (length(indice)>0 & length(indice)<=24) {
				 #colunas=dados[indice,4]
				 #colunas=ifelse(colunas==0,24,colunas) # troca 0 por 24
				 perfis_temperatura[i,1:length(indice)]=dados[indice,6]
			 }
		}
		rm(dados)
		
	 
	rownames(perfis_temperatura)=as.character(dias_historico)
}else{
	serietemphist=dados
	ind=which((dados[,1]>=rownames(seriecarga)[1])&(dados[,1]<=rownames(seriecarga)[length(rownames(seriecarga))]))
	serietemphist=serietemphist[ind,2]
}
printUI(sessionUI, paste("CONCLUIDA LEITURA DO ARQUIVO",filename))












#======================================
# CRIA DATA.FRAME COM DADOS HISTORICOS 
#======================================

if (tipodiario==0){
	DATAHIST=data.frame(matriz_perfis_carga,x_feriados,x_verao,perfis_temperatura)
	# Monta series historicas
	seriecarga=c()
	serieferiados=c()
	seriehorverao=c()
	serietemphist=c()
	for (i in 1:numdias) {
		 seriecarga=c(seriecarga,matriz_perfis_carga[i,1:24])
		 serieferiados=c(serieferiados,rep(x_feriados[i],24))
		 seriehorverao=c(seriehorverao,rep(x_verao[i],24))
		 serietemphist=c(serietemphist,perfis_temperatura[i,1:24])
	}
	SERIEHIST=data.frame(seriecarga,serieferiados,seriehorverao,serietemphist)
	colnames(SERIEHIST)=c("carga","feriado","horverao","temperatura")  

	DADOSLIDOS=list(DATAHIST=DATAHIST,SERIEHIST=SERIEHIST,tipodiario=tipodiario,abatecarga=abatecarga,precipitacao=precipitacao)
}else{

	DATAHIST=data.frame(seriecarga,x_feriados,x_verao,serietemphist)
	colnames(DATAHIST)=c("carga","feriado","horverao","temperatura")  
	DADOSLIDOS=list(DATAHIST=DATAHIST,tipodiario=tipodiario,abatecarga=abatecarga,precipitacao=precipitacao)
}

return(DADOSLIDOS)
}

#' @title Programa ROTINA DE FILTRAGEM DE DADOS HISTORICOS DO PREVCARGADESSEM
#' @name FILTRAGEM
#'
#' @description FILTRA DADOS DE CARGA
#' 
#' @param (numeroclusters,perfis,seriecarga,DADOS)
#' 
#' @details 
#'
#'
#' @return DADOS DE CARGA FILTRADOS
#'
#' @author CEPEL
#'
#'
#'
#' @export 
FILTRAGEM=function(sessionUI,DADOS,tipodiario){

# PARAMETROS DE ENTRADA: numeroclusters: numero de clusters da analise de agrupamentos
#                        perfis: matriz contendo dados de carga, temperatura e indicacao de feriado/
#                                horario de verao em cada linha (carga e temperatura em bases horarias)
#                        seriecarga: serie temporal da carga em bases horarias
#                        TIPOTEMP=0 NAO FILTRA ARTQUIVO DE TEMPERATURA
# VARIAVEIS DE SAIDA: DATAHIST_FILTRADOS: data.frame contendo dados para cada dia do historico
#                                         cada linha representa um dia #                     colunas de 1 a 24 guardam a demanda media horaria
#                                         coluna 25 indicacao de feriado 
#                                         coluna 26 indicacao de horario de verao
#                                         colunas 27 a 50 guardam as temperaturas medias horarias
#                     SERIEHIST_FILTRADAS: data.frame contendo dados historicos de carga, temperatura, feriados
#                                          e horario de verao na forma de serie temporais
#                                          coluna 1 serie temporal da carga filtrada
#                                          coluna 2 serie temporal com indicacao de feriados
#                                          coluna 3 serie temporal com indicacao de horario de verao
#                                          coluna 4 serie temporal da temperatura media horaria filtrada
#                     TABELAS_NAIVE_BAYES: tabelas do classificador naive bayes
#                     TIPOLOGIAS: perfis tipicos em pu da media diaria

#===============================================
# FILTRA SERIE DE PRECIPITACAO - PREENCHE VALORES DIARIOS FALTANTES
#===============================================

  precipitacao=DADOS$precipitacao
  if (sum(precipitacao!=0)>0){
    #precipitacao=precipitacao[-nrow(precipitacao),]
    #datasp=as.Date(paste0(unlist(precipitacao[,3]),"/",unlist(precipitacao[,2]),"/",unlist(precipitacao[,1])),format=' %d/%m/%Y')
    datasp=as.Date(precipitacao$datas)
    datasp=with_tz(as.POSIXct(datasp),"GMT")
    
    #datasc=seq(from=as.POSIXct(datasp[1],tz="America/Sao_Paulo"),to=as.POSIXct(tail(datasp,1), tz="America/Sao_Paulo"), by="day")
    datasc=seq(from=as.POSIXct(datasp[1],tz="GMT"),to=as.POSIXct(tail(datasp,1),tz="GMT"), by="day")
    datasc=data.frame(data=datasc)
    
    precipitacao=data.frame(data=datasp,prec=precipitacao[,2])
    #arq=full_join(datasc,precipitacao)
    arq=merge(datasc,precipitacao,by.x = "data",all=TRUE)
    arq2=arq
    
    arq[which(is.na(arq[,2])),2]=0
    arq[,1]=format(arq[,1],'%Y-%m-%d')
    arq=arq[order(arq[,1]),]
    
    arq2[,1]=format(arq2[,1],'%Y-%m-%d')
    arq2=arq2[order(arq2[,1]),]
    
    precipitacao=data.frame(datas=as.Date(arq[,1]),precipitacao=as.numeric(arq[,2]))
    precipitacao_orig=data.frame(datas=as.Date(arq2[,1]),precipitacao=arq2[,2])
  }else{
    precipitacao=0
    precipitacao_orig=0
    
  }
  


	if (tipodiario==0){
		perfis=DADOS$DATAHIST
		carga=perfis[,1:24]
		feriados=perfis[,25]
		verao=perfis[,26]
		datas=rownames(DADOS$DATAHIST)

		seriecarga=DADOS$SERIEHIST[,1]


		numeroclusters=40
		treinamodelo=1
		tipotemp=1


		#printUI(sessionUI, paste("FILTRANDO DADOS DE TEMPERATURA..."))
		#=====================================
		# TRATAMENTO DOS DADOS DE TEMPERATURA 
		#=====================================
		temperatura=matrix(0,dim(carga)[1],dim(carga)[2])
		if (tipotemp!=0) {
			# Remove NA da temperarura
			diastemperaturaNA=rep(0,dim(perfis)[1])
			diastemperaturaNA[which(is.na(apply(perfis[,27:50],1,mean))==T)]=1 # perfis com NA
			meses=as.numeric(substr(datas,6,7))
			anos=as.numeric(substr(datas,1,4))
			indiceNA=which(is.na(apply(perfis[,27:50],1,mean))==T)
			if (length(indiceNA)>0){
				# entra aqui se ha NA (lacuna) na temperatura
				for (i in 1:length(indiceNA)){
					 NAperfil=26+which(is.na(perfis[indiceNA[i],27:50])==T) # horas do perfil com NA (colunas da matriz perfis com temperatura)
					 if (indiceNA[i]>1 & indiceNA[i]<dim(perfis)[1]) {
						 if (diastemperaturaNA[indiceNA[i]-1]==0 & diastemperaturaNA[indiceNA[i]+1]==0) {
							 perfis[indiceNA[i],NAperfil]=0.5*(perfis[(indiceNA[i]-1),NAperfil]+perfis[(indiceNA[i]+1),NAperfil])
							 diastemperaturaNA[indiceNA[i]]=0
						 } 
					 } 
					 if (indiceNA[i]>1 & diastemperaturaNA[indiceNA[i]]==1 & diastemperaturaNA[indiceNA[i]-1]==0) {
						 perfis[indiceNA[i],NAperfil]=perfis[(indiceNA[i]-1),NAperfil]
						 diastemperaturaNA[indiceNA[i]]=0
					 } 
					 if (indiceNA[i]<dim(perfis)[1] & diastemperaturaNA[indiceNA[i]]==1 & diastemperaturaNA[indiceNA[i]+1]==0) {
						 perfis[indiceNA[i],NAperfil]=perfis[(indiceNA[i]+1),NAperfil]
						 diastemperaturaNA[indiceNA[i]]=0
					 }      
					 if (diastemperaturaNA[indiceNA[i]]==1) {
						 # entra aqui se NA ainda nao foi corrigido
						 indicemesano=which(meses==as.numeric(substr(datas[indiceNA[i]],6,7)) & anos==as.numeric(substr(datas[indiceNA[i]],1,4)) & diastemperaturaNA==0)
						 if (length(indicemesano)>0) {
							perfis[indiceNA[i],NAperfil]=apply(perfis[indicemesano,NAperfil],2,mean)
						 } else {
							indicemesano=which(diastemperaturaNA==0)
							perfis[indiceNA[i],NAperfil]=apply(perfis[indicemesano,NAperfil],2,mean)          
						 }
						 rm(indicemesano)
						 diastemperaturaNA[indiceNA[i]]=0
					 }
				}
			}                                       
			#serietemperatura=c()
			#for (i in 1:dim(perfis)[1]) {
			#    serietemperatura=c(serietemperatura,as.numeric(perfis[i,27:50]))
			#}
			serietemperatura=as.vector(t(perfis[,27:50]))
			temperatura=perfis[,27:50]
			rm(indiceNA)
			rm(diastemperaturaNA)
			rm(meses)
			rm(anos)

			# remove outliers da temperatura
			# padroniza variavel temperatura: x1 = (temperatura-xbarra)/S		
			x1=(serietemperatura-mean(serietemperatura))/sd(serietemperatura)
			x1suave=ksmooth(seq(1,length(x1),1),x1,bandwidth=50) # serie suavizada por Nadaraya-Watson
			limsup=x1suave$y+3.5*sd(x1suave$y-x1) # limite superior do intervalo de confianca
			liminf=x1suave$y-3.5*sd(x1suave$y-x1) # limite inferior do intervalo de confianca
			indiceoutliers1=which(x1<liminf) # indice dos outliers
			indiceoutliers2=which(x1>limsup) # indice dos outliers 
			x1[indiceoutliers1]=x1suave$y[indiceoutliers1] # substituicao dos outliers por valores suavizados
			x1[indiceoutliers2]=x1suave$y[indiceoutliers2] # substituicao dos outliers por valores suavizados
			serietemperatura_filtrada=x1*sd(serietemperatura)+mean(serietemperatura) # serie filtrada
			# perfis de temperatura filtrada
			temperatura=matrix(serietemperatura_filtrada,dim(carga)[1],dim(carga)[2],byrow=T)
			rm(x1)
			rm(x1suave)
			rm(limsup)
			rm(liminf)
			rm(indiceoutliers1)
			rm(indiceoutliers2)
		}

		#printUI(sessionUI, paste("FILTRANDO DADOS DE CARGA..."))
		#===============================
		# TRATAMENTO DOS DADOS DE CARGA 
		#===============================
		# substitui valores negativos por zero
		seriecarga=ifelse(seriecarga<0,0,seriecarga)

		# identifica erros grosseiros com a ajusta do boxplot da serie temporal da carga
		outliers=boxplot(seriecarga,plot=F)$out
		outliers=as.numeric(names(table(outliers)))
		noutliers=length(outliers)

		if (length(which(seriecarga>boxplot(seriecarga,plot=F)$stats[5,1]*1.05))>0){
			seriecarga[which(seriecarga>boxplot(seriecarga,plot=F)$stats[5,1]*1.05)]=0 #limite superior
		}
		if (length(which(seriecarga<=boxplot(seriecarga,plot=F)$stats[1,1]))>0){
			seriecarga[which(seriecarga<=boxplot(seriecarga,plot=F)$stats[1,1]/2)]=0  #limite inferior
		}

		carga=data.frame(matrix(seriecarga,dim(carga)[1],dim(carga)[2], byrow = TRUE))
		rownames(carga)=rownames(perfis)


		# percorre perfis diarios de carga e verifica status do perfil
		# status = 0 perfil diario e bom
		nperfiscarga=dim(carga)[1]
		status=rep(0,nperfiscarga) # guarda o numero de valores errados
		for (i in 1:nperfiscarga) {
			somalinha=sum(carga[i,])
			if (somalinha==0) {
				# entra aqui se nao ha dados de carga para o dia i
				status[i]=-1 # -1 indice perfil com todos os valores nulos
			} else {           
				aux=c()
				if (noutliers>0){
					aux=which(carga[i,]==0)
				# for (j in 1:noutliers) {
					# aux=c(aux,which(carga[i,]==outliers[j]))
				# carga[i,which(carga[i,]==outliers[j])]=0
					# }
			}
				contador=length(aux)          
				if (contador>0) status[i]=contador # status = numero de outliers no perfil diario
			}
		}


		#=========================================
		# ANALISE DE AGRUPAMENTOS DOS PERFIS BONS 
		#=========================================
		# faz analise de agrupamentos dos perfis com status=0 (perfis bons)
		# perfis em pu da media
		indice=which(status!=0)
		indice12=which(feriados==12) # marca dias de blecautes e jogos da copa
		if (length(indice)>0) {
			if (length(indice12)>0) {
				perfispu=carga[-unique(c(indice,indice12)),] # apenas perfis com status=0 (perfis bons) e sem blecautes e copa 
			} else {
				perfispu=carga[-indice,] # apenas perfis com status=0 (perfis bons)   
			}
		} else {
			if (length(indice12)>0) {
			  perfispu=carga[-indice12,] # apenas perfis com status=0 (perfis bons) e sem blecautes e copa 
			} else {
			  perfispu=carga 
			}
		}
		media=apply(perfispu,1,mean) # medias dos perfis diarios
		perfispu=sweep(perfispu,1,media,FUN="/") # aqui coloca perfis em pu da media
		diasemana=weekdays1(as.Date(rownames(perfispu)))
		mes=substr(rownames(perfispu),6,7)
		resultado=hclust(dist(perfispu),"ward.D2") # executa analise de agrupamentos dos perfis

		# pega dados dos perfis que participaram dos clusters
		if (tipotemp!=0){
		   if (length(indice)>0) {
			   if (length(indice12)>0) {
				   xtemperatura=temperatura[-unique(c(indice,indice12)),] # apenas temperaturas dos dias com perfis bons e sem blecautes e copa
			   } else {
				   xtemperatura=temperatura[-indice,] # apenas temperaturas dos dias com perfis bons
			   }
		   } else {
			   if (length(indice12)>0) {
				   xtemperatura=temperatura[-indice12,] # sem blecautes e copa
			   } else {
				   xtemperatura=temperatura  
			   }
		   }
		   xmediatemperatura=apply(xtemperatura,1,median) # mediana da temperatura
		   xmintemperatura=apply(xtemperatura,1,min) # temperatura minima
		   xmaxtemperatura=apply(xtemperatura,1,max) # temperatura maxima
		}
		if (length(indice)>0) {
			if (length(indice12)>0) {
			  xferiados=as.character(feriados[-unique(c(indice,indice12))]) # apenas feriados dos dias com perfis bons e sem blecautes e copa
			  xverao=verao[-unique(c(indice,indice12))] # apenas horario de verao com perfis bons
			} else {
			  xferiados=as.character(feriados[-indice]) # apenas feriados dos dias com perfis bons e sem blecautes e copa
			  xverao=verao[-indice] # apenas horario de verao com perfis bons
			}
		} else {
			if (length(indice12)>0) {
			  xferiados=as.character(feriados[-indice12]) # apenas feriados dos dias com perfis bons e sem blecautes e copa
			  xverao=verao[-indice12] # apenas horario de verao com perfis bons e sem blecautes e copa
			} else {
			  xferiados=as.character(feriados) # apenas feriados dos dias com perfis bons 
			  xverao=verao # apenas horario de verao com perfis bons  
			}
		}
		xverao=ifelse(xverao==1,"VERAO","HNORMAL")

		# pega solucao com numeroclusters
		clusters=cutree(resultado,numeroclusters)
		xclusters = as.character(paste("C",clusters,sep=""))
		perfis_tipicos=c()
		for (i in 1:numeroclusters) {
			indicecurvasnocluster=which(clusters==i)
			perfis_tipicos=rbind(perfis_tipicos,apply(perfispu[indicecurvasnocluster,],2,mean))
		}
		rownames(perfis_tipicos)=as.character(paste("C",seq(1,numeroclusters,1),sep=""))
		colnames(perfis_tipicos)=as.character(paste("Hora.",seq(1,24,1),sep=""))

		dadosNB=data.frame(diasemana,mes,xferiados,xverao,xclusters) # dados classificados para o Naive Bayes

		#==================================================================
		# AJUSTA SVM PARA ESTIMACAO DA DEMANDA MEDIA DIARIA                
		# O RESULTADO SERA UTILIZADO NO AJUSTE DOS DIAS SEM DADOS DE CARGA 
		#==================================================================
		if (tipotemp!=0) {
			XX1=apply(temperatura,1,median)/100
			XX2=apply(temperatura,1,max)/100
			XX3=apply(temperatura,1,min)/100
		}
		XX4=feriados
		XX5=verao
		XX6=as.numeric(substr(rownames(carga),6,7))/12 # mes
		XX7=matrix(0,length(weekdays1(as.Date(rownames(carga)))),6) # dia da semana
		nomesdiassemanas=c("domingo","segunda-feira","terca-feira","quarta-feira","quinta-feira","sexta-feira","sabado") 
		diasemana=weekdays1(as.Date(rownames(carga)))
		for (i in 1:6) {
			XX7[grep(nomesdiassemanas[i],diasemana),i]=1
		}
		YY=apply(carga,1,mean)/100000
		YY=loess(YY~seq(1,length(YY),1),span=0.1)$fitted

		lags=c(1,7)
		# forma padroes de entrada/saida excluindo os casos com missing data na carga
		XX1n=c()
		XX2n=c()
		XX3n=c()
		XX4n=c()
		XX5n=c()
		XX6n=c()
		XX7n=c()
		XX8n=c()
		YYn=c()

		for (i in max(lags+1):length(YY)) {
			if (sum(status[c(i,(i-lags))])==0 & XX4[i]!=12) {
			   # entra aqui se os dias envolvidos apresentam perfis bons e sem blecuate e jogo da copa
			   if (tipotemp!=0) {
				  XX1n=c(XX1n,XX1[i])
				  XX2n=c(XX2n,XX2[i])
				  XX3n=c(XX3n,XX3[i])
			   }
			   XX4n=c(XX4n,(XX4[i]/12)) # MODIFICADO 19 JULHO 2018
			   XX5n=c(XX5n,XX5[i])
			   XX6n=c(XX6n,XX6[i])
			   XX7n=rbind(XX7n,XX7[i,])
			   aux=YY[(i-lags)] # vetor com valores passados da demanda    
			   XX8n=rbind(XX8n,aux)
			   YYn=c(YYn,YY[i])
			}
		}
		rownames(XX8n)=NULL
		if (tipotemp!=0) {
			datatrain=data.frame(XX1n,XX2n,XX3n,XX4n,XX5n,XX6n,XX7n,XX8n,YYn)
			colnames(datatrain)[13:(13+(length(lags)-1))]=paste("Lag",lags,sep="")
		} else {
			datatrain=data.frame(XX4n,XX5n,XX6n,XX7n,XX8n,YYn)
			colnames(datatrain)[10:(10+(length(lags)-1))]=paste("Lag",lags,sep="")
		}

		if (treinamodelo==1) {
			# Ajusta um SVM
			#aux=tune(svm, YYn~., data = datatrain,ranges = list(epsilon=c(0.01,0.05,0.1), gamma = c(0.01,0.05,0.1), cost = c(1000,10000))) # COMENTADO 19 JULHO 2018
			aux=tune(svm, YYn~., data = datatrain,ranges = list(epsilon=c(0.01,0.1), cost = c(1,10)))
			ksv=aux$best.model
			#save(ksv,file="svm1.rda")
		} else {
			#load(file="svm1.rda")
		}
		previsao=predict(ksv,datatrain[,-dim(datatrain)[2]])
		# demandas medias estimadas
		demandasmediasestimadas=previsao*100000
		#rm(XX1n);rm(XX2n);rm(XX3);rm(XX4n);rm(XX5n);rm(XX6n);rm(XX7n);rm(XX8n);rm(YYn)

		#==============================================
		# CORRIGE CASOS SEM DADOS DE CARGA (STATUS -1) 
		#==============================================
		# inicializa matriz com carga filtrada
		cargafiltrada=carga

		# classificador Naive Bayes
		# tabelas de probabilidades apriori e condicionais
		tabelas=naiveBayes(xclusters~diasemana+mes+xferiados+xverao,laplace=1,data=dadosNB)
		#indice=which(status==-1)
		indice=which(status!=0)
		if (length(indice)>0) {
		   x1=weekdays1(as.Date(rownames(carga)[indice]))
		   x1mes=substr(as.Date(rownames(carga)[indice]),6,7)
		   x2=as.character(feriados[indice])
		   x3=ifelse(verao[indice]>0,"VERAO","HNORMAL")
		   entrada=data.frame(x1,x1mes,x2,x3)
		   names(entrada)=c("diasemana","mes","xferiados","xverao")
		   # previsao para preeenchimento dos dias sem dados de carga
		   ## clusterparamissingdata=predict(classificador,newdata=entrada)
		   ## calculo da posteriori sem usar a rotina predict
		   clusterparamissingdata=c()
		   for (i in 1:dim(entrada)[1]) {
				coluna1=which(x1[i]==colnames(tabelas$tables$diasemana))
				coluna1mes=which(x1mes[i]==colnames(tabelas$tables$mes))
				coluna2=which(x2[i]==colnames(tabelas$tables$xferiados))
				coluna3=which(x3[i]==colnames(tabelas$tables$xverao))
				produto=rep(0,numeroclusters)
				for (j in 1:numeroclusters) {
					 if (x2[i]==0) {
						 # entra aqui se dia normal
						 produto[j]=tabelas$apriori[j]*tabelas$tables$diasemana[j,coluna1]
						 produto[j]=produto[j]*tabelas$tables$mes[j,coluna1mes]
						 produto[j]=produto[j]*tabelas$tables$xferiados[j,coluna2]
						 produto[j]=produto[j]*tabelas$tables$xverao[j,coluna3]
					 } else {
						 if (x2[i]!=12){
							 # se feriado ou dia especial
							 produto[j]=tabelas$apriori[j]*tabelas$tables$diasemana[j,coluna1]
							 produto[j]=produto[j]*tabelas$tables$xferiados[j,coluna2]
							 produto[j]=produto[j]*tabelas$tables$xverao[j,coluna3]
						 } else {
							 # blecaute ou jogo da copa
							 produto[j]=tabelas$apriori[j]*tabelas$tables$diasemana[j,coluna1]
							 produto[j]=produto[j]*tabelas$tables$xverao[j,coluna3]
						 }
					 }
				}
				clusterparamissingdata=c(clusterparamissingdata,names(tabelas$apriori[which(produto==max(produto))]))
		 
				# preenche dias sem dados de carga
				XX1=mean(as.numeric(temperatura[indice[i],]))/100
				XX2=max(as.numeric(temperatura[indice[i],]))/100
				XX3=min(as.numeric(temperatura[indice[i],]))/100
				XX4=feriados[indice[i]]
				if (XX4==12) {
					XX4=0
				} else {
					XX4=XX4/12
				}
				XX5=verao[indice[i]]
				XX6=as.numeric(substr(rownames(carga[indice[i],]),6,7))/12 # mes
				XX7=rep(0,6) 
				aux=weekdays1(as.Date(rownames(carga[indice[i],])))       
				if (grep(aux,nomesdiassemanas)<7) XX7[grep(aux,nomesdiassemanas)]=1
				XX8=YY[(indice[i]-lags)] # vetor com valores passados da demanda
				if (tipotemp==0) padrao=c(XX4,XX5,XX6,XX7,XX8)
				if (tipotemp>0) padrao=c(XX1,XX2,XX3,XX4,XX5,XX6,XX7,XX8)
				names(padrao)=colnames(datatrain[-length(datatrain)])
				demandasmediasestimadas=predict(ksv,t(padrao))*100000
				indicecurvasnocluster=which(clusterparamissingdata[i]==xclusters)
				cargafiltrada[indice[i],]=apply(perfispu[indicecurvasnocluster,],2,mean)*demandasmediasestimadas
		   }
		}

		#===============================================
		# PASSA FILTRO NADARAYA WATSON NA SERIE DE CARGA 
		#===============================================
		seriecargafiltrada=as.vector(t(cargafiltrada))

		# padroniza variavel 		
		x1=(seriecargafiltrada-mean(seriecargafiltrada))/sd(seriecargafiltrada)
		x1suave=ksmooth(seq(1,length(x1),1),x1,bandwidth=50) # serie suavizada por Nadaraya-Watson
		limsup=x1suave$y+3.5*sd(x1suave$y-x1) # limite superior do intervalo de confianca
		liminf=x1suave$y-3.5*sd(x1suave$y-x1) # limite inferior do intervalo de confianca
		indiceoutliers1=which(x1<liminf) # indice dos outliers
		indiceoutliers2=which(x1>limsup) # indice dos outliers 
		x1[indiceoutliers1]=x1suave$y[indiceoutliers1] # substituicao dos outliers por valores suavizados
		x1[indiceoutliers2]=x1suave$y[indiceoutliers2] # substituicao dos outliers por valores suavizados
		seriecargafiltrada=x1*sd(seriecargafiltrada)+mean(seriecargafiltrada) # serie filtrada


		#========================      
		# MONTA OBJETOS DE SAIDA 
		#========================
		serieferiado=as.vector(t(outer(feriados,rep(1,24))))
		serieverao=as.vector(t(outer(verao,rep(1,24))))

		if (tipotemp==0) {
			SERIEHIST_FILTRADAS=data.frame(seriecargafiltrada,serieferiado,serieverao,rep(0,length(seriecargafiltrada)))
		} else {
			SERIEHIST_FILTRADAS=data.frame(seriecargafiltrada,serieferiado,serieverao,serietemperatura_filtrada)
		}

		cargafiltrada=matrix(seriecargafiltrada,dim(carga)[1],dim(carga)[2],byrow=T)
		DATAHIST_FILTRADOS=data.frame(cargafiltrada,feriados,verao,temperatura,precipitacao)
		rownames(DATAHIST_FILTRADOS)=rownames(perfis)

		#printUI(sessionUI, paste("LEITURA CONCLUIDA."))
		printUI(sessionUI, "Arquivos de entrada lidos com sucesso.")
		
		# EXPORTA LISTA DADOSFILTRADOS
		DADOSFILTRADOS=list(DATAHIST_FILTRADOS=DATAHIST_FILTRADOS,SERIEHIST_FILTRADAS=SERIEHIST_FILTRADAS,TABELAS_NAIVE_BAYES=tabelas,TIPOLOGIAS=perfis_tipicos)
	}else{
			# DADOS$DATAHIST[[length(DADOS$DATAHIST)+1]]=precipitacao
			# names(DADOS$DATAHIST)[length(DADOS$DATAHIST)]=precipitacao
			FILTRO=DADOS$DATAHIST
			if (length(which(is.na(DADOS$DATAHIST[,4])))>0) DADOS$DATAHIST[which(is.na(DADOS$DATAHIST[,4])),4]=0
			if (length(which(is.na(FILTRO[,4])))>0) FILTRO[which(is.na(FILTRO[,4])),4]=FILTRO[which(is.na(FILTRO[,4]))-1,4]
			DADOSFILTRADOS=list(DATAHIST_FILTRADOS=FILTRO,PRECIPITACAO=precipitacao,PRECORIG=precipitacao_orig)
			#printUI(sessionUI, paste("LEITURA CONCLUIDA."))
			printUI(sessionUI, "Arquivos de entrada lidos com sucesso.")
			

}
return(DADOSFILTRADOS)
}


#' @title Programa printUI
#' @name printUI
#'
#' @description imprime mensagem no console ou no shiny
#' 
#' @param (session, msg)
#' 
#' @details 
#'
#'
#' @return mensagem
#'
#' @author CEPEL
#'
#'
#'
#' @export 
printUI <- function(session, msg) {
  if(is.null(session)){
    print(msg)
  }else{
    msg = paste0(msg, "\n", collapse = "")
    session$sendCustomMessage("handler1", msg)
  }
}


#' @title Programa WEEKDAYS1
#' @name weekdays1
#'
#' @description RETIRA O ACENTO DE STRINGS
#' 
#' @param (diasemana)
#' 
#' @details 
#'
#'
#' @return STRINGS SEM ACENTO
#'
#' @author CEPEL
#'
#'
#'
#' @export 
weekdays1 <-function(data) {
            # data = data
	    # diasemana = dia da semana com acento
            # diasemanaSA = dia da semana sem acento
                    
            datanum=as.numeric(format(as.Date(data),"%w"))
	    diasemanaSA=datanum
	    diasemanaSA[which(datanum==0)]="domingo"
	    diasemanaSA[which(datanum==1)]="segunda-feira"
	    diasemanaSA[which(datanum==2)]="terca-feira"
	    diasemanaSA[which(datanum==3)]="quarta-feira"
	    diasemanaSA[which(datanum==4)]="quinta-feira"
	    diasemanaSA[which(datanum==5)]="sexta-feira"
	    diasemanaSA[which(datanum==6)]="sabado"
   	    return(diasemanaSA)					
					
}


#10 @title Programa MODELODSA
#10 @name modelodsa
#10
#10 @description aplica dsa a serie de carga
#10 
#10 @param (seriecargadiaria,serietempdiaria,selecferiados)
#10 
#10 @details 
#10
#10
#10 @return carga ajustada sem o efeito calendario
#10
#10 @author CEPEL
#10
#10
#10
#10 
modelodsa<-function(seriecargadiaria,serietempdiaria,selecferiados,config,abatecarga,serieprecipitacao,feriados){
  
  save(seriecargadiaria,serietempdiaria,selecferiados,config,abatecarga,serieprecipitacao,feriados,file='entrada.Rdata')
  
  ### executa DSA versao2
  x=xts(as.numeric(seriecargadiaria),frequency=365,order.by=as.Date(rownames(seriecargadiaria))) # carga
  ind=which((month(time(x))==2)&(day(time(x))==29))
  if (length(ind)>0) x= x[-ind]
  # Create extra holiday regressors -----------------------------------------
  
  # Base regressor 
  dates <- seq(as.Date("2000-01-01"),as.Date("2030-12-31"),by="days") 
  Base  <- xts::xts(rep(0,length(dates)),order.by=dates)
  
  # Easter related holidays
  CorpusChristi<- ChristmasDay<- ChristmasEve <-NewYearsDay <- GoodFriday <- EasterSunday <- EasterMonday <- Base
  
  GoodFriday[as.Date(timeDate::GoodFriday(2000:2030))] <- 1
  EasterSunday[as.Date(timeDate::EasterSunday(2000:2030))] <- 1
  EasterMonday[as.Date(timeDate::EasterMonday(2000:2030))] <- 1
  CorpusChristi[as.Date(timeDate::CorpusChristi(2000:2030))] <- 1
  
  HolySaturday <- Lag0(EasterSunday, -1)
  HolyThursday <- Lag0(EasterSunday, -3)
  EasterMondayAft1Day <- Lag0(EasterMonday, 1)
  ChristmasDay[as.Date(timeDate::ChristmasDay(2000:2030))] <- 1
  ChristmasEve[as.Date(timeDate::ChristmasEve(2000:2030))] <- 1
  NewYearsDay[as.Date(timeDate::NewYearsDay(2000:2030))] <- 1
  
  NewYearsEve<- Lag0(NewYearsDay, -1)
  CarnivalMonday <- Lag0(EasterSunday, -48)
  MardiGras <- Lag0(EasterSunday, -47)
  CarnivalWednesday<- Lag0(EasterSunday, -46)
  
  #Brazilian holidays
  Tiradentes <- LabourDay <- IndependenceDay <- LadyOfAparecida <- DayOfTheDead <- RepublicProclamation <- Base
  Tiradentes[format(zoo::index(Tiradentes), "%m-%d")=="04-21"] <- 1
  LabourDay[format(zoo::index(LabourDay), "%m-%d")=="05-01"] <- 1
  IndependenceDay[format(zoo::index(IndependenceDay), "%m-%d")=="09-07"] <- 1
  LadyOfAparecida[format(zoo::index(LadyOfAparecida), "%m-%d")=="10-12"] <- 1
  DayOfTheDead[format(zoo::index(DayOfTheDead), "%m-%d")=="11-02"] <- 1
  RepublicProclamation[format(zoo::index(RepublicProclamation), "%m-%d")=="11-15"] <- 1
  
  # Calendar and Seasonal Adjustment ----------------------------------------
  Holidays <- merge(NewYearsDay,CarnivalMonday,MardiGras,CarnivalWednesday,GoodFriday,EasterSunday,Tiradentes,LabourDay,CorpusChristi,IndependenceDay,LadyOfAparecida,DayOfTheDead,RepublicProclamation,ChristmasEve,ChristmasDay,NewYearsEve)
  nomesferiados=c("1 janeiro","Segunda-feira carnaval","Terca-feira carnaval","Quarta-feira cinzas","Sexta-feira Santa","Pascoa","Tiradentes","1 maio",'CorpusChristi',"7 setembro","NS Aparecida","Finados","15 novembro","24 Dezembro","Natal","31 dezembro")
  
  
  ###ADCIONA FERIADOS REGIONAIS CADASTRADOS
  ## Feriados regionais - CODIGO 11 NO ARQUIVO DE FERIADOS
  # regional=rownames(seriecargadiaria)[which((feriados==1)|(feriados==2))]
  # regional=regional[which(is.na(regional)==FALSE)]
  # nomeregional=c()
  # aux=c()
  # for (i in 1:length(regional)){
  #   ind=which(ymd(regional)==ymd(regional[i]) + years(1)|ymd(regional)==ymd(regional[i])-years(1))
  #   if (length(ind)!=0) aux=c(aux,regional[i])
  #   
  # }
  # regional=aux
  # 
  # aux=c()
  # for (i in 1:length(regional)){
  #   if  (sum(Holidays[which(time(Holidays)==regional[i]),])==0)  aux=c(aux,regional[i])
  # }
  # regional=aux
  # 
  # if (length(regional)>0){
  #   nomeregional=regional
  #   nomeregional=unique(paste0(sprintf("%02d",day(nomeregional)),"/",sprintf("%02d",month(nomeregional))))
  # }
  
  nomeregional=c()
  newregional=unique(feriados[which(feriados>12)])
  if (length(newregional)>0) nomeregional=c(nomeregional,newregional)
  
  
  if (length(nomeregional)>0){
    for (i in 1:length(nomeregional)){
      auxbase=Base
      if (nchar(nomeregional[i])==5){
        auxbase[which(month(time(auxbase))==as.numeric(substr(nomeregional[i],4,5))&
                        day(time(auxbase))==as.numeric(substr(nomeregional[i],1,2)))]<-1
        assign(nomeregional[i],auxbase)
        nomereg=nomeregional[i]
      }else{
        ind=rownames(seriecargadiaria)[which(feriados==nomeregional[i])]
        for (j in 1:length(ind)){
          auxbase[which(time(auxbase)==ind[j])]<-1
        }
        nomereg=paste0(substr(ind[1],9,10),"-",substr(ind[1],6,7))
        assign(nomereg,auxbase)
      }
      
      for (k in 1:ncol(Holidays)){
        d=time(Holidays)[which(Holidays[,k]==1)[1]]
        if (as.numeric(substr(nomereg,4,5))==(month(d))){
          if (as.numeric(substr(nomereg,1,2))>(day(d))){
            Holidays=merge(Holidays[,1:k],eval(as.symbol(nomereg)),Holidays[,(k+1):ncol(Holidays)])
            nomesferiados=c(nomesferiados[1:k],nomeregional[i],nomesferiados[(k+1):length(nomesferiados)])
            names(Holidays)[which(substr(names(Holidays),1,4)=='eval')]=nomeregional[i]
            break
          }
          Holidays=merge(Holidays[,1:k-1],eval(as.symbol(nomereg)),Holidays[,(k):ncol(Holidays)])
          nomesferiados=c(nomesferiados[1:k-1],nomeregional[i],nomesferiados[(k):length(nomesferiados)])
          names(Holidays)[which(substr(names(Holidays),1,4)=='eval')]=nomeregional[i]
          break
          if (as.numeric(substr(nomereg,1,2))==(day(d))) break
        }
        
        if (as.numeric(substr(nomereg,4,5))<(month(d))){
          if (k>1) Holidays=merge(Holidays[,1:k-1],eval(as.symbol(nomereg)),Holidays[,(k):ncol(Holidays)])
          if (k==1) Holidays=merge(eval(as.symbol(nomereg)),Holidays[,(k):ncol(Holidays)])
          nomesferiados=c(nomesferiados[1:k-1],nomeregional[i],nomesferiados[(k):length(nomesferiados)])
          names(Holidays)[which(substr(names(Holidays),1,4)=='eval')]=nomeregional[i]
          break
        }
      }
      
    }
    #(eval(as.symbol(nomeregional[i])))
  }
  
  Holidays_regionais=Holidays
  nomesferiados_regionais=nomesferiados
  
  
  reference_series <- x
  restrict <- seq.Date(from=stats::start(reference_series), to=stats::end(reference_series), by="days")
  restrict_forecast <- seq.Date(from=stats::end(reference_series)+1,length.out=366, by="days")
  ind=which((month(as.Date(restrict_forecast))==2)&(day(as.Date(restrict_forecast))==29))
  HolidaysUse <- multi_xts2ts(Holidays[restrict])
  HolidaysForecast <- multi_xts2ts(Holidays[restrict_forecast], short=TRUE)
  HolidaysForecast <- HolidaysForecast[1:365,colSums(HolidaysUse)!=0]
  HolidaysUse <- HolidaysUse[,colSums(HolidaysUse)!=0]
  
  #swindows=as.numeric(config$stl)
  swindows=c(as.numeric(config$stl),151,15)
  #swindows=as.numeric(strsplit(config$stl,',')[[1]])
  res <- dsa(x, Log=config$log, model = config$model,fourier_number = as.numeric(config$fourier), s.window1=swindows[1], s.window2=swindows[2], s.window3=swindows[2], robust3=FALSE, regressor=HolidaysUse, forecast_regressor = HolidaysForecast)
  
  saida=res$sa_result[,2]
  inicio=head(as.Date(rownames(seriecargadiaria)),1)
  fim=tail(as.Date(rownames(seriecargadiaria)),1)
  saidacal=window(saida,start=inicio,end=fim)
  
  saida=res$sa_result2[,2]
  saidafer=window(saida,start=inicio,end=fim)
  
  #########################################################
  # carga ajustada pelos efeitos calendario e temperatura #
  #########################################################
  saidatemp=0
  if (length(serietempdiaria)>1){
    
    # Additional weather adjustment ------------------------------------------
    temperature <- xts(as.numeric(serietempdiaria),frequency=365,order.by=as.Date(rownames(seriecargadiaria))) 
    
    mes=as.numeric(substr(rownames(data.frame(temperature)),6,7))
    for (i in 1:12) {
      temperature[which(mes==i)]=temperature[which(mes==i)]-mean(temperature[which(mes==i)])
    }
    temperature_res <- dsa(temperature, s.window1=401, s.window2=401, s.window3=13, fourier_number = 30, h=730) # Using the RegARIMA Forecast from DSA to extrapolate the temperature
    Temperature <- del_names(temperature_res$output$original)
    
    Holidays <- merge(Holidays_regionais,Temperature)
    nomesferiadostemp=c(nomesferiados_regionais,"Temperatura")
    
    x=xts(as.numeric(seriecargadiaria),frequency=365,order.by=as.Date(rownames(seriecargadiaria))) # carga
    ind=which((month(time(x))==2)&(day(time(x))==29))
    if (length(ind)>0) x= x[-ind]
    reference_series <- x
    restrict <- seq.Date(from=stats::start(reference_series), to=stats::end(reference_series), by="days")
    restrict_forecast <- seq.Date(from=stats::end(reference_series)+1,length.out=366, by="days")
    HolidaysUse <- multi_xts2ts(Holidays[restrict])
    HolidaysForecast <- multi_xts2ts(Holidays[restrict_forecast], short=TRUE)
    HolidaysForecast <- HolidaysForecast[1:365,colSums(HolidaysUse)!=0]
    HolidaysUse <- HolidaysUse[,colSums(HolidaysUse)!=0]
    
    restemp <- dsa(x, Log=config$log,model = config$model, fourier_number = as.numeric(config$fourier), s.window1=swindows[1], s.window2=swindows[2], s.window3=swindows[2], robust3=FALSE, regressor=HolidaysUse, forecast_regressor = HolidaysForecast)
    
    saida=restemp$sa_result[,2]
    inicio=head(as.Date(rownames(seriecargadiaria)),1)
    fim=tail(as.Date(rownames(seriecargadiaria)),1)
    saidatemp=window(saida,start=inicio,end=fim)
    
    resprec=0
    saidaprec=rep(0,length(saidatemp))
    if(length(serieprecipitacao)>1){
      
      ###################################################
      # ### AJUSTE ADICIONAL PELA SERIE DE PRECIPITACAO #
      ###################################################
      
      # Additional weather adjustment ------------------------------------------
      precipitation <- xts(as.numeric(serieprecipitacao[,2]),frequency=365,order.by=as.Date(rownames(seriecargadiaria))) 
      
      #aano=as.numeric(substr(serieprecipitacao[,1],1,4))
      #mes=as.numeric(substr(serieprecipitacao[,1],6,7))
      #for (j in min(aano):max(aano)){
      #	  for (i in 1:12) {
      #	      indicemesano=which(mes==i & aano==j)
      #       if (length(indicemesano)>0){
      #            precipitation[indicemesano]=precipitation[indicemesano]-mean(precipitation[indicemesano])
      #	      }
      #   }
      #}
      
      mes=as.numeric(substr(rownames(data.frame(precipitation)),6,7))
      for (i in 1:12) {
        precipitation[which(mes==i)]=(precipitation[which(mes==i)]-mean(precipitation[which(mes==i)],na.rm=T))
      }
      
      #write.csv(data.frame(xx,temperature,precipitation),"DSAserie.csv")
      
      precipitation_res <- dsa(precipitation, s.window1=401, s.window2=401, s.window3=13, fourier_number = 30, h=730) # Using the RegARIMA Forecast from DSA to extrapolate the temperature
      Precipitation <- del_names(precipitation_res$output$original)
      
      
      Holidays <- merge(Holidays_regionais,Temperature,Precipitation)
      nomesferiadosprec=c(nomesferiados_regionais,"Temperatura","Precipitacao")
      
      reference_series <- x
      restrict <- seq.Date(from=stats::start(reference_series), to=stats::end(reference_series), by="days")
      restrict_forecast <- seq.Date(from=stats::end(reference_series)+1,length.out=366, by="days")
      ind=which((month(as.Date(restrict_forecast))==2)&(day(as.Date(restrict_forecast))==29))
      HolidaysUse <- multi_xts2ts(Holidays[restrict])
      HolidaysForecast <- multi_xts2ts(Holidays[restrict_forecast], short=TRUE)
      HolidaysForecast <- HolidaysForecast[1:365,colSums(HolidaysUse)!=0]
      HolidaysUse <- HolidaysUse[,colSums(HolidaysUse)!=0]
      
      resprec <- dsa(x, Log=config$log,model = config$model, fourier_number = as.numeric(config$fourier), s.window1=swindows[1], s.window2=swindows[2], s.window3=swindows[2], robust3=FALSE, regressor=HolidaysUse, forecast_regressor = HolidaysForecast)
      
      saida=resprec$sa_result[,2]
      inicio=head(as.Date(rownames(seriecargadiaria)),1)
      fim=tail(as.Date(rownames(seriecargadiaria)),1)
      saidaprec=window(saida,start=inicio,end=fim)
      
    }
  }
  #save(res,restemp,resprec,file='res.Rdata')
  
  coeficientes_regressao=0
  if (length(serietempdiaria)>1){
    # coeficientes dos feriados
    inicio=which(names(restemp$reg$coef)=="NewYearsDay" )
    fim=length(names(restemp$reg$coef))-1
    indiceferiado=seq(inicio,fim,1)
    coeficientes_feriados=coef(restemp$reg)[indiceferiado] # coeficiente do feriado
    if (config$log==TRUE) coeficientes_feriados=mean(seriecargadiaria)*(exp(coeficientes_feriados)-1)
    names(coeficientes_feriados)=nomesferiados
    
    # coeficientes dos regressores
    if (length(coef(res$reg))>max(indiceferiado)) {
      indicereg=seq((max(indiceferiado)+1),length(coef(restemp$reg)),1)
      coeficientes_regressao=coef(restemp$reg)[indicereg]
    }
    
    # coeficientes dos regressores
    coeficientes_regressao2=0
    if (length(serieprecipitacao)>2){
      if (length(coef(restemp$reg))>max(indiceferiado)) {
        indicereg=seq(length(coef(restemp$reg))+1,length(coef(resprec$reg)),1)
        coeficientes_regressao2=coef(resprec$reg)[indicereg]
      }
    }
    
  }else{
    # coeficientes dos feriados
    inicio=which(names(res$reg$coef)=="NewYearsDay" )
    fim=length(names(res$reg$coef))
    indiceferiado=seq(inicio,fim,1)
    coeficientes_feriados=coef(res$reg)[indiceferiado] # coeficiente do feriado
    if (config$log==TRUE) coeficientes_feriados=mean(seriecargadiaria)*(exp(coeficientes_feriados)-1)
    names(coeficientes_feriados)=nomesferiados
  }
  
  # estimativa para o dia 29 de fevereiro - saidatemp
  #if (is.na(saidatemp[1])) saidatemp[1]=restemp$output$seas_adj[1]
  #if (is.na(saidatemp[1])) saidatemp[1]=xx[8]
  
  auxsaida=saidatemp
  dia29fev=which(is.na(auxsaida))
  if (length(dia29fev)>0) {
    for (i in 1:length(dia29fev)) {
      i0=dia29fev[i] # dia 29 de fevereiro
      vizinhanca=seq((i0-8*7),(i0+8*7),7) # pega mesmos dias da semana do dia 29 de fevereiro
      vizinhanca=vizinhanca[-9]
      vizinhanca=vizinhanca[which((vizinhanca>0) & (vizinhanca<=length(auxsaida)))]
      y=auxsaida[vizinhanca]
      out=1
      if (out==1) auxsaida[i0]=mean(y$cal_adj)
    }
  }
  saidatemp=auxsaida
  #saidatemp=cargaadjTarima
  
  # estimativa para o dia 29 de fevereiro - saidacal
  #if (is.na(saidacal[1])) saidacal[1]=res$output$seas_adj[1]
  #if (is.na(saidacal[1])) saidacal[1]=xx[8]
  
  auxsaida=saidacal
  dia29fev=which(is.na(auxsaida))
  if (length(dia29fev)>0) {
    for (i in 1:length(dia29fev)) {
      i0=dia29fev[i] # dia 29 de fevereiro
      vizinhanca=seq((i0-8*7),(i0+8*7),7) # pega mesmos dias da semana do dia 29 de fevereiro
      vizinhanca=vizinhanca[-9]
      vizinhanca=vizinhanca[which((vizinhanca>0) & (vizinhanca<=length(auxsaida)))]
      y=auxsaida[vizinhanca]
      out=1
      if (out==1) auxsaida[i0]=mean(y$cal_adj)
    }
  }
  saidacal=auxsaida
  
  if (length(serieprecipitacao)>1){
    # estimativa para o dia 29 de fevereiro - saidaprec
    #if (is.na(saidaprec[1])) saidaprec[1]=resprec$output$seas_adj[1]
    #if (is.na(saidaprec[1])) saidaprec[1]=xx[8]
    auxsaida=saidaprec
    dia29fev=which(is.na(auxsaida))
    if (length(dia29fev)>0) {
      for (i in 1:length(dia29fev)) {
        i0=dia29fev[i] # dia 29 de fevereiro
        vizinhanca=seq((i0-8*7),(i0+8*7),7) # pega mesmos dias da semana do dia 29 de fevereiro
        vizinhanca=vizinhanca[-9]
        vizinhanca=vizinhanca[which((vizinhanca>0) & (vizinhanca<=length(auxsaida)))]
        y=auxsaida[vizinhanca]
        out=1
        if (out==1) auxsaida[i0]=mean(y$cal_adj)
      }
    }
    saidaprec=auxsaida
    #saidaprec=cargaadjParima
  }
  
  # monta serie media mensal
  #   cargamensaladj=c()
  #   cargamensalobs=c()
  # 	cargamensalcal=c()
  # 	cargamensalprec=c()
  # 	datas=index(x)
  #   ano1=as.numeric(substr(datas,1,4))
  #   mes1=as.numeric(substr(datas,6,7))
  # 	dia1=as.numeric(substr(datas,9,10))
  #   for (iano in min(ano1):max(ano1)){
  #       for (imes in 1:12){
  #           aux=which(ano1==iano & mes1==imes)
  #           if (imes==2) {
  # 	    		    # NAO CONTA 29 DE FEVEREIRO
  #               aux=which(ano1==iano & mes1==imes & dia1<29)
  # 			    }
  #           if (length(aux)>0) {
  # 			      	if (length(serieprecipitacao)>1) cargamensalprec=c(cargamensalprec,mean(saidaprec[aux],na.rm=T))
  # 				      if (length(serieprecipitacao)==0) cargamensalprec=c(cargamensalprec,0) 
  #               cargamensaladj=c(cargamensaladj,mean(saidatemp[aux],na.rm=T))
  #               cargamensalobs=c(cargamensalobs,mean(seriecargadiaria[aux],na.rm=T))
  # 				      cargamensalcal=c(cargamensalcal,mean(saidacal[aux],na.rm=T))
  # 		      } 
  #       }
  #   }    
  
  df=data.frame(seriecargadiaria,saidatemp,saidacal,saidaprec)
  names(df)=c('obs','saidatemp','saidacal','saidaprec')
  df$Month <- month(rownames(df))
  df$Year <- year(rownames(df))
  cargamensalobs=aggregate( obs ~ Month + Year , df , mean )[,3]
  cargamensaladj=aggregate( saidatemp ~ Month + Year , df , mean )[,3]
  cargamensalcal=aggregate( saidacal ~ Month + Year , df , mean )[,3]
  
  if (length(serieprecipitacao)>1){
    cargamensalprec=aggregate( saidaprec ~ Month + Year , df , mean )[,3]
  }else{
    cargamensalprec=0*cargamensalobs
  }
  
  meses=unique(format(as.Date(rownames(seriecargadiaria)),format="%Y-%m"))
  cargamensaladjabate=rep(0,length(cargamensalobs))
  cargamensalobsabate=rep(0,length(cargamensalobs))
  if (length(abatecarga)>1){
    if((abatecarga[1,1]<=meses[1])&(abatecarga[nrow(abatecarga),1]>=meses[length(meses)])){
      abatecarga=abatecarga[(which(abatecarga[,1]==meses[1])):(which(abatecarga[,1]==meses[length(meses)])),2]
      cargamensalobsabate=cargamensalobs-abatecarga
      cargamensaladjabate=cargamensaladj-abatecarga
      if (sum(cargamensalprec)>0) cargamensaladjabate=cargamensalprec-abatecarga
      
    }
  }else{
    cargamensalobsabate=cargamensalobs
    cargamensaladjabate=cargamensaladj
    if (sum(cargamensalprec)>0) cargamensaladjabate=cargamensalprec-abatecarga
  }
  
  # SAIDACAL apenas ajuste ao calendario em base diaria
  # SAIDATEMP ajuste ao calendario e temperatura em base diaria
  # COEFERIADOS coeficientes dos feriados
  # COEFREG coeficientes dos regressores , no momento apenas temperatura
  # MENSALOBS carga mensal observada
  # MENSALCAL carga mensal ajustada calendario
  # MENSALADJ carga mensal ajustada calendario/temperatura
  # MENSALPREC carga mensal ajustada calendario/temperatura/precipitacao
  # DIARIAADJ carga diaria ajustada igual a SAIDACAL ou SAIDATEMP mas com 29 de fevereiro
  # coeficientes_regressao=0
  # coeficientes_regressao2=0
  teste=data.frame(MENSALOBS=cargamensalobs,MENSALADJPREC=cargamensalprec,MENSALADJ=cargamensaladj,MENSALCAL=cargamensalcal,MENSALADJABATE=cargamensaladjabate,MENSALOBSABATE=cargamensalobsabate)
  write.table(teste,'teste.csv',sep=';',dec='.',quote = F,row.names = F,col.names = F)
  return=list(SAIDACAL=saidacal,SAIDAFER=saidafer,SAIDATEMP=saidatemp,SAIDAPREC=saidaprec,COEFERIADOS=coeficientes_feriados,COEFREG=coeficientes_regressao,COEFREG2=coeficientes_regressao2,MENSALOBS=cargamensalobs,MENSALADJPREC=cargamensalprec,MENSALADJ=cargamensaladj,MENSALCAL=cargamensalcal,DIARIAADJ=auxsaida,MENSALADJABATE=cargamensaladjabate,MENSALOBSABATE=cargamensalobsabate)
}


#' @title Programa EXECUTADSA	
#' @name executadsa
#'
#' @description aplica dsa a serie de carga
#' 
#' @param (seriecargadiaria,serietempdiaria,selecferiados)
#' 
#' @details 
#'
#'
#' @return carga ajustada sem o efeito calendario
#'
#' @author CEPEL
#'
#'
#'
#' @export 
EXECUTADSA<-function(DADOSDSA,periodo,config,abatecarga,precipitacao,feriados){
			#####################
			# Ajusta modelo DSA #
			#####################
	    #save(DADOSDSA,periodo,config,abatecarga,precipitacao,feriados,file='dadosdsa.Rdata')		
      
      feriados=feriados[(which(rownames(DADOSDSA)==periodo[1]):which(rownames(DADOSDSA)==periodo[2]))]
  		DADOSDSA=DADOSDSA[(which(rownames(DADOSDSA)==periodo[1]):which(rownames(DADOSDSA)==periodo[2])),]
			
			serieprecipitacao=0
			if (length(precipitacao)>1) if ((periodo[1]>=precipitacao[1,1])&(periodo[2]<=precipitacao[nrow(precipitacao),1])) serieprecipitacao=precipitacao[(which(precipitacao[,1]==periodo[1])):(which(precipitacao[,1]==periodo[2])),]
			
			tipodiario=1
			if (dim(DADOSDSA)[2]>4) tipodiario=0
			if (tipodiario==0){
				cargadia2=apply(DADOSDSA[,1:24],1,mean)
				tempdia=apply(DADOSDSA[,27:50],1,mean) # temperatura
			}else{
				cargadia2=DADOSDSA[,1]
				tempdia=DADOSDSA[,4] # temperatura
				names(cargadia2)=rownames(DADOSDSA)
				names(tempdia)=rownames(DADOSDSA)
			}
			
			
			
			
			
			# lista de feriados
			# (1) 1 janeiro
			# (2) segunda de carnaval 
			# (3) terca de carnaval 
			# (4) quarta feira de cinzas 
			# (5) sexta feira santa 
			# (6) Pascoa 
			# (7) 21 abril 
			# (8) Dia do trabalho 
			# (9) Corpus Christi 
			# (10) 7 setembro 
			# (11) 12 outubro 
			# (12) 2 novembro 
			# (13) 15 novembro 
			# (14) vespera de Natal  
			# (15) Natal 
			selecferiados=seq(1,15,1) # seleciona feriados , se seq(1,15,1) considerada todos

			cargadia3=cbind(cargadia2)
			rownames(cargadia3)=names(cargadia2)
			
			teste=cbind(cargadia2,feriados)
			rownames(teste)=names(cargadia2)

			saidadsa=modelodsa(cargadia3,tempdia,selecferiados,config,abatecarga,serieprecipitacao,feriados)
				
			# efeito_feriado=saidadsa$COEFERIADOS # coeficientes de regressao dos feriados
			# serie_ajustada_feriado=saidadsa$SAIDA # serie ajustada sem efeito calendario
				
			return(saidadsa)

}



#' @title DSACEPEL
#' @name DSACEPEL
#'
#' @description Used to call the module DSACEPEL 
#' 
#' @param dsaCepel(series,span.start,model,Log,Diff,automodel,ic,fourier_number,s.window1,s.window2,s.window3,t.window1,t.window2,t.window3,cval,robust1,robust2,robust3,regressor,forecast_regressor,reg.create,reg.dummy,outlier.types,modelspan,feb29,trend_month,outer3,inner3,h,reiterate3,scaler,progressBar)
#' 
#' @details 
#' \itemize{
#'  \item series
#' } 
#'
#' @return 
#' \itemize{
#'  \item output
#'  \item sa_result
#'  \item sa_result2
#' }
#'
#' @author Brazilian Electric Power Research Center - CEPEL
#'
#'
#'
#' @export 
dsaCepel<-function (series, span.start = NA, model = NULL, Log = FALSE, 
    Diff = 0, automodel = "reduced", ic = "bic", 
    fourier_number = NA, s.window1 = 151, s.window2 = 51, s.window3 = 15, 
    t.window1 = NULL, t.window2 = NULL, t.window3 = NULL, cval = 7, 
    robust1 = TRUE, robust2 = TRUE, robust3 = TRUE, regressor = NULL, 
    forecast_regressor = NULL, reg.create = NULL, reg.dummy = NULL, 
    outlier.types = c("AO", "LS", "TC"), modelspan = NULL, 
    feb29 = "sfac", trend_month = 3, outer3 = NULL, inner3 = NULL, 
    h = 365, reiterate3 = NULL, scaler = 1e+07, progressBar = TRUE) 
{
    if (min(series, na.rm = TRUE) <= 0 & Log) {
        stop("Series contains non-positive values. Only positive values allowed for multiplicative time series model. Set Log=FALSE")
    }
    if (h >= 10 & h%%365 != 0) {
        warning("Forecast horizon h should be smaller than 10 or a multiple of 365. Might give problems if specification contains holiday regressors")
    }
    if (h < 10 & h > 0) {
        h <- h * 365
    }
    if (max(abs(series), na.rm = TRUE) > 1e+05 & !Log) {
        Euro400 <- series/scaler
    } else {
        Euro400 <- series
    }
    times <- as.POSIXlt(seq.Date(from = as.Date(xts::first(zoo::index(Euro400))), 
        to = as.Date(xts::last(zoo::index(Euro400))), by = "days"))
    attr(times, "tzone") <- "GMT"
    attr(zoo::index(Euro400), "tzone") <- "GMT"
    times <- round(times, "days")
    Fill <- xts::xts(rep(NA, times = length(times)), order.by = times)
    Euro400 <- xts::merge.xts(Fill, Euro400)[, 2]
    if (progressBar) {
        total <- 1
        pb <- utils::txtProgressBar(title = "Seasonal adjustment of Daily Data", 
            min = 0, max = total, width = NA, label = "Configuring data", 
            style = 3)
        utils::setTxtProgressBar(pb, 1/21, title = "Seasonal adjustment of Daily Data", 
            label = "Configuring data")
    }
    if (is.na(span.start)) {
        span.start = stats::start(Euro400)
    }
    startingvalue <- suppressWarnings(c(as.integer(format(xts::first(zoo::index(Euro400[paste(span.start, 
        "/", sep = "")])), "%Y")), timeDate::dayOfYear(timeDate::timeDate(xts::first(zoo::index(Euro400[paste(span.start, 
        "/", sep = "")])), "%Y-%m-%d") + 13000)))
    if (progressBar) {
        utils::setTxtProgressBar(pb, 2/21, label = "Estimating Day-of-the-Week")
    }
    Euro400 <- zoo::na.locf(Euro400)
    Euro400_7 <- stats::ts(as.numeric(Scaler(Euro400[paste(span.start, 
        "/", sep = "")], Diff = Diff, Log = Log)), 
        frequency = 7, start = startingvalue)
    stl_1 <- stats::stl(Euro400_7, s.window = s.window1, robust = robust1, 
        t.window = t.window1)
    stl1_E400 <- stl_1
    v1 = stl_1$time.series[, 2] + stl_1$time.series[, 3]
    s1 <- Descaler(v1, Diff = Diff, y = Euro400[paste(span.start, 
        sep = "")])
    s1 <- s1 - mean(s1) + mean(Scaler(Euro400, Log = Log))
    times <- as.POSIXlt(seq.Date(from = as.Date(xts::first(zoo::index(Euro400))), 
        to = as.Date(xts::last(zoo::index(Euro400))), by = "days"))
    s1_xts <- xts::xts(s1, order.by = xts::last(times, n = length(s1)))
    s1_xts[format(zoo::index(s1_xts), "%m-%d") == "02-29"] <- NA
    s1_xts <- stats::na.omit(s1_xts)
    sstart <- c(as.integer(format(zoo::index(s1_xts)[1], "%Y")), 
        as.integer(timeDate::dayOfYear(timeDate::timeDate(zoo::index(s1_xts[1])))))
    sstart[2] <- min(365, sstart[2])
    s1_ts <- stats::ts(s1_xts, start = sstart, freq = 365)[, 
        1]
    if (is.null(reg.dummy)) {
        hol <- makeCal(holidays = reg.create, h = h, original = s1_xts, 
            original2 = s1_ts)
    } else {
        hol <- makeDummy(holidays = reg.create, from = reg.dummy[1], 
            to = reg.dummy[2], h = h, original = s1_xts, original2 = s1_ts)
    }
    if (!is.null(modelspan)) {
        keep_s1_ts <- s1_ts
        s1_ts <- stats::window(s1_ts, start = c(stats::end(s1_ts)[1] - 
            modelspan, stats::end(s1_ts)[2]), end = stats::end(s1_ts))
        keep_s1_xts <- s1_xts
        s1_xts <- ts2xts(s1_ts)
        keep_regressor <- regressor
        ll <- length(s1_ts)
        ll2 <- length(keep_s1_ts)
        regressor <- regressor[(ll2 - ll + 1):length(s1_ts)]
        if (is.null(reg.dummy)) {
            keep_hol <- hol
            hol <- makeCal(holidays = reg.create, h = h, original = s1_xts, 
                original2 = s1_ts)
        } else {
            keep_hol <- hol
            hol <- makeDummy(holidays = reg.create, from = reg.dummy[1], 
                to = reg.dummy[2], h = h, original = s1_xts, 
                original2 = s1_ts)
        }
    }
    aicc400 <- aicc400_2 <- bic400 <- rep(NA, times = 30)
    if (!is.null(model)) {
        if (progressBar) {
            utils::setTxtProgressBar(pb, 5/21, label = "Estimating preliminary ARIMA model")
        }
        automodel = NULL
        s_arima365_prior = data.frame(arma = rep(0, 6))
        s_arima365_prior$arma[1] = model[1]
        s_arima365_prior$arma[6] = model[2]
        s_arima365_prior$arma[2] = model[3]
    }
    if (!is.null(automodel)) {
        if (progressBar) {
            utils::setTxtProgressBar(pb, 6/21, label = "Estimating prelimary automatic ARIMA model")
        }
        if (substr(automodel, 1, 1) == "r") {
            s_arima365_prior <- tryCatch(forecast::auto.arima(s1_ts, 
                stepwise = TRUE, max.d = 1, seasonal = F, ic = ic, 
                xreg = cbind(forecast::fourier(s1_ts, 24)[, c(1:10, 
                  c(23:24, 47:48))], hol$mhol, regressor)), error = function(e) e)
            if (inherits(s_arima365_prior, "error")) {
                s_arima365_prior$arma[1] <- 1
                s_arima365_prior$arma[6] <- 1
                s_arima365_prior$arma[2] <- 0
            }
        }
        if (substr(automodel, 1, 1) == "f") {
            s_arima365_prior <- tryCatch(forecast::auto.arima(s1_ts, 
                stepwise = TRUE, max.d = 1, seasonal = F, ic = ic, 
                xreg = cbind(forecast::fourier(s1_ts, 24), hol$mhol, 
                  regressor)), error = function(e) e)
            if (inherits(s_arima365_prior, "error")) {
                s_arima365_prior$arma[1] <- 1
                s_arima365_prior$arma[6] <- 1
                s_arima365_prior$arma[2] <- 0
            }
        }
    }
    if (is.na(fourier_number)) {
        for (j in 1:30) {
            a3 <- tryCatch(forecast::Arima(s1_ts, order = c(s_arima365_prior$arma[1], 
                s_arima365_prior$arma[6], s_arima365_prior$arma[2]), 
                xreg = cbind(forecast::fourier(s1_ts, j), hol$mhol, 
                  regressor), method = "ML"), error = function(e) e)
            if (inherits(a3, "error")) {
                next
            }
            aicc400[j] <- a3$aicc
        }
    } else {
        aicc400 <- rep(NA, times = 30)
        aicc400[fourier_number] <- 5
    }
    if (length(aicc400[!is.na(aicc400)]) == 0) {
        aicc400[24] <- 4.3391883295
    }
    s_arima365 <- forecast::Arima(s1_ts, order = c(s_arima365_prior$arma[1], 
        s_arima365_prior$arma[6], s_arima365_prior$arma[2]), 
        xreg = cbind(forecast::fourier(s1_ts, which.min(aicc400)), 
            hol$mhol, regressor), method = "ML")
    if (progressBar) {
        utils::setTxtProgressBar(pb, 8/21, label = "Outlier Detection")
    }
    cval_new <- cval
    ol <- tryCatch(suppressWarnings(outlier(series = s1_ts, model = s_arima365, 
        cval = cval, types = outlier.types, holidays = cbind(hol$mhol, 
            regressor), number.fourier = which.min(aicc400))), 
        error = function(e) e)
    if (inherits(ol, "error")) {
        cval_new <- cval_new + 1
        ol <- tryCatch(suppressWarnings(outlier(series = s1_ts, 
            model = s_arima365, cval = cval_new, types = outlier.types, 
            holidays = cbind(hol$mhol, regressor), number.fourier = which.min(aicc400))), 
            error = function(e) e)
    }
    if (inherits(ol, "error")) {
        cval_new <- cval_new + 1
        ol <- tryCatch(suppressWarnings(outlier(series = s1_ts, 
            model = s_arima365, cval = cval_new, types = outlier.types, 
            holidays = cbind(hol$mhol, regressor), number.fourier = which.min(aicc400))), 
            error = function(e) e)
    }
    if (inherits(ol, "error")) {
        s1_ol <- s1_ts
        outlier_effect <- rep(0, length(s1_ol))
    }
    if (!inherits(ol, "error")) {
        s1_ol <- ol$series_adj
        outlier_effect <- ol$outlier_eff
    }
    if (progressBar) {
        utils::setTxtProgressBar(pb, 14/21, label = "Estimating calendar effects")
    }

    # CEPEL 2 agosto 2020
    xregBR = cbind(forecast::fourier(s1_ts,which.min(aicc400)), hol$mhol, regressor)
    colnames(xregBR)<-colnames(cbind(forecast::fourier(s1_ts,which.min(aicc400), h = h), hol$lhol, forecast_regressor))
    # CEPEL 2 agosto 2020

    arima_reg365 <- forecast::Arima(s1_ol, order = c(s_arima365$arma[1], 
        s_arima365$arma[6], s_arima365$arma[2]), xreg = xregBR, method = "ML", 
        include.constant = TRUE)
    model_aicc_E400 <- arima_reg365
    arima_reg365 <<- arima_reg365
    h <<- h
    s1_ts <<- s1_ts
    aicc400 <<- aicc400
    hol <<- hol
    forecast_regressor <<- forecast_regressor
    fc1 <- forecast::forecast(arima_reg365, h = h, xreg = cbind(forecast::fourier(s1_ts, 
        which.min(aicc400), h = h), hol$lhol, forecast_regressor))
    if (!is.null(modelspan)) {
        firstpart <- keep_s1_ts[1:(length(keep_s1_ts) - length(s1_ts))]
        s1_fc <- stats::ts(c(firstpart, fc1$model$x, fc1$mean), 
            start = stats::start(keep_s1_ts), frequency = 365)
        hol <- keep_hol
        regressor <- keep_regressor
        s1_xts <- keep_s1_xts
        s1_ts <- keep_s1_ts
    } else {
        s1_fc <- stats::ts(c(fc1$model$x, fc1$mean), start = stats::start(s1_ts), 
            frequency = 365)
    }
    if (!is.null(reg.create)) {
        if (is.null(dim(hol$mhol))) {
            cf <- ((model_aicc_E400$coef[grep("hol", names(model_aicc_E400$coef))]) * 
                (c(hol$mhol, hol$lhol)))
        } else {
            cf <- rep(0, times = (dim(hol$mhol)[1] + dim(hol$lhol)[1]))
            for (k in 1:dim(hol$mhol)[2]) {
                cf <- cf + ((model_aicc_E400$coef[grep("hol", 
                  names(model_aicc_E400$coef))][k]) * (rbind(hol$mhol, 
                  hol$lhol)[, k]))
            }
        }
        k1 <- s1_fc - cf
    } else {
        k1 <- s1_fc
    }
    if (!is.null(regressor)) {
        if (is.null(dim(as.data.frame(regressor)))) {
            cf <- ((model_aicc_E400$coef[length(model_aicc_E400$coef)]) * 
                (c(regressor, forecast_regressor)))
        } else {
            cf <- 0
            for (k in 1:dim(as.data.frame(regressor))[2]) {
                cf <- cf + ((model_aicc_E400$coef[(length(model_aicc_E400$coef) + 
                  1 - dim(as.data.frame(regressor))[2]):length(model_aicc_E400$coef)][k]) * 
                  (rbind(matrix(regressor, nrow = nrow(data.frame(regressor))), 
                    matrix(forecast_regressor, nrow = nrow(data.frame(forecast_regressor))))[, 
                    k]))
            }
        }
        k1 <- k1 - cf
    } else {
        k1 <- k1
    }
    if (progressBar) {
        utils::setTxtProgressBar(pb, 15/21, label = "Estimating Day-Of-Month Effect")
    }
    k1_xts <- ts2xts(k1)
    k1_complete <- k1_xts
    k1_31 <- fill31(k1_xts, fill = "spline")
    k1x <- stats::ts(Scaler(k1_31, Diff = Diff), frequency = 31)
    stl_2 <- stats::stl(k1x, s.window = s.window2, robust = robust2, 
        t.window = t.window2)
    stl2_E400 <- stl_2
    s2_31 <- stats::ts(as.numeric(Descaler(stl_2$time.series[, 
        2] + stl_2$time.series[, 3], Diff = Diff, y = ts2xts(s1_ts))), 
        start = stats::start(k1_31), freq = 372)
    s2 <- s2_31 - mean(s2_31) + mean(k1_31)
    s2 <- drop31(s2, new_start = stats::start(k1)[2], new_end = stats::end(k1)[2])
    s2_complete <- s2
    s2 <- xts2ts(s2, freq = 365)
    if (progressBar) {
        utils::setTxtProgressBar(pb, 16/21, label = "Estimating Day-Of-Year Effect")
    }
    if (is.null(outer3)) {
        outerval = if (robust3) 
            15
        else 0
    } else {
        outerval = outer3
    }
    if (is.null(inner3)) {
        innerval = if (robust3) 
            1
        else 2
    }  else {
        innerval = inner3
    }
    s2x <- Scaler(s2, Diff = Diff)
    stl_3 <- stats::stl(s2x, s.window = s.window3, robust = robust3, 
        outer = outerval, inner = innerval, t.window = t.window3)
    s3 <- stats::ts(as.numeric(Descaler(stl_3$time.series[, 2] + 
        stl_3$time.series[, 3], y = ts2xts(s1_ts), Diff = Diff)), 
        start = startingvalue, frequency = 365)
    if (!is.null(reiterate3)) {
        for (i in 1:reiterate3) {
            s3 <- Scaler(s3, Diff = Diff)
            stl_3 <- stats::stl(s3, s.window = s.window3, robust = robust3, 
                outer = outerval, inner = innerval, t.window = t.window3)
            s3 <- stats::ts(as.numeric(Descaler(stl_3$time.series[, 
                2] + stl_3$time.series[, 3], y = ts2xts(s1_ts), 
                Diff = Diff)), start = startingvalue, frequency = 365)
        }
    }
    s3_E400 <- s3
    stl3_E400 <- stl_3
    if (progressBar) {
        utils::setTxtProgressBar(pb, 16/21, label = "Preparing set of final time series")
    }
    s_final <- s3 + c(outlier_effect, rep(xts::last(outlier_effect), 
        times = (length(s3) - length(outlier_effect))))
    outlier_effect_xts <- ts2xts(s_final - s3)
    times <- as.POSIXlt(seq.Date(from = as.Date(xts::first(zoo::index(Euro400))), 
        to = as.Date(xts::last(zoo::index(Euro400))) + h, by = "days"))
    attr(times, "tzone") <- "GMT"
    attr(zoo::index(Euro400), "tzone") <- "GMT"
    Fill <- xts::xts(rep(NA, times = length(times)), order.by = times)
    s_final_xts <- suppressWarnings(zoo::na.spline(xts::merge.xts(a = ts2xts(s_final), 
        Fill)$a[paste(span.start, "/", sep = "")]))
    n_t = ceiling(365/(12/trend_month))
    if (n_t - n_t%/%2 * 2 == 0) {
        n_t <- n_t + 1
    }
    fraction = n_t/length(s_final_xts)
    trend_xts <- xts::xts(stats::predict(stats::loess(s_final_xts ~ 
        seq.int(length(s_final_xts)), span = fraction), newdata = seq.int(length(s_final_xts))), 
        order.by = zoo::index(s_final_xts))
    times <- as.POSIXlt(seq.Date(from = as.Date(xts::first(zoo::index(Euro400))), 
        to = as.Date(xts::last(zoo::index(Euro400))) + h, by = "days"))
    attr(times, "tzone") <- "GMT"
    attr(zoo::index(Euro400), "tzone") <- "GMT"
    Fill <- xts::xts(rep(NA, times = length(times)), order.by = times)
    Fill <- Fill[paste(xts::first(zoo::index(s1_xts)), "/", 
        sep = "")]
    s1_x <- ts2xts(s1_fc)
    s1_x <- xts::merge.xts(s1_x, Fill)$s1_x
    outlier_effect2 <- stats::ts(suppressWarnings(as.numeric(outlier_effect)), 
        start = stats::start(s1_ts), freq = 365)
    outliers <- ts2xts(outlier_effect2)
    outliers <- xts::merge.xts(outliers, Fill)$outliers
    outliers[is.na(outliers)] <- xts::last(outliers[!is.na(outliers)])
    sf_x <- day_split(stl_1$time.series[, 1], use = "ets", 
        h = h)$sf
    times <- as.POSIXlt(seq.Date(from = as.Date(xts::first(zoo::index(s1_xts))), 
        length.out = length(sf_x), by = "days"))
    attr(times, "tzone") <- "GMT"
    attr(zoo::index(Euro400), "tzone") <- "GMT"
    sf_x_xts <- xts::xts(sf_x, order.by = times)
    times <- as.POSIXlt(seq.Date(from = as.Date(xts::first(zoo::index(s1_xts))), 
        length.out = length(sf_x) + 1, by = "days"))
    comp <- Scaler(Euro400[paste(xts::first(zoo::index(s1_x)), 
        "/", sep = "")], Log = Log) - as.numeric(xts::first(s1_x)) - 
        as.numeric(xts::first(outliers))
    s1_fac <- Descaler(xts::xts(sf_x, order.by = seq.Date(as.Date(stats::start(comp)), 
        length.out = length(sf_x), by = "days")), Diff = Diff, 
        y = comp)
    original_forecast <- s1_x + outliers + s1_fac
    s1_complete <- original_forecast - s1_fac
    o_fc_xts <- fill_up(original_forecast, Scaler(Euro400, Log = Log))
    s_final_xts <- s_final_xts - mean(xts::first(s_final_xts, 
        length(s_final_xts) - h), na.rm = TRUE) + mean(xts::first(o_fc_xts, 
        length(o_fc_xts) - h), na.rm = TRUE)
    s1_complete <- Descaler(s1_complete - mean(xts::first(s1_complete, 
        length(s_final_xts) - h), na.rm = TRUE) + mean(xts::first(o_fc_xts, 
        length(o_fc_xts) - h), na.rm = TRUE), Log = Log, y = NA)
    k1_complete <- k1_complete + outlier_effect_xts
    k1_complete <- Descaler(k1_complete - mean(xts::first(k1_complete, 
        length(s_final_xts) - h), na.rm = TRUE) + mean(xts::first(o_fc_xts, 
        length(o_fc_xts) - h), na.rm = TRUE), Log = Log, y = NA)
    s2_complete <- s2_complete + outlier_effect_xts
    s2_complete <- Descaler(s2_complete - mean(xts::first(s2_complete, 
        length(s_final_xts) - h), na.rm = TRUE) + mean(xts::first(o_fc_xts, 
        length(o_fc_xts) - h), na.rm = TRUE), Log = Log, y = NA)
    s1_only <- s1_complete
    g <- Descaler(Scaler(s1_complete, Log = Log) - Scaler(k1_complete, 
        Log = Log), Log = Log, y = NA)
    v <- Descaler(o_fc_xts, Log = Log, y = NA)
    k1_only <- Descaler(Scaler(v, Log = Log) - Scaler(g, Log = Log), 
        Log = Log, y = NA)
    k1_only <- k1_only - mean(xts::first(k1_only, length(k1_only) - 
        h), na.rm = TRUE) + mean(xts::first(Descaler(o_fc_xts, 
        Log = Log, y = NA), length(k1_only) - h), na.rm = TRUE)
    g <- Descaler(Scaler(k1_complete, Log = Log) - Scaler(s2_complete, 
        Log = Log), Log = Log, y = NA)
    v <- Descaler(o_fc_xts, Log = Log, y = NA)
    s2_only <- Descaler(Scaler(v, Log = Log) - Scaler(g, Log = Log), 
        Log = Log, y = NA)
    s2_only <- s2_only - mean(xts::first(s2_only, length(s2_only) - 
        h), na.rm = TRUE) + mean(xts::first(Descaler(o_fc_xts, 
        Log = Log, y = NA), length(s2_only) - h), na.rm = TRUE)
    g <- Descaler(Scaler(s2_complete, Log = Log) - s_final_xts, 
        Log = Log, y = NA)
    v <- Descaler(o_fc_xts, Log = Log, y = NA)
    s3_only <- Descaler(Scaler(v, Log = Log) - Scaler(g, Log = Log), 
        Log = Log, y = NA)
    s3_only <- s3_only - mean(xts::first(s3_only, length(s3_only) - 
        h), na.rm = TRUE) + mean(xts::first(Descaler(o_fc_xts, 
        Log = Log, y = NA), length(s3_only) - h), na.rm = TRUE)
    trend <- trend_xts - mean(xts::first(trend_xts, length(trend_xts) - 
        h), na.rm = TRUE) + mean(xts::first(o_fc_xts, length(o_fc_xts) - 
        h), na.rm = TRUE)
    sc_fac <- Descaler(o_fc_xts - s_final_xts, Log = Log, y = NA) * 
        ifelse(Log, 100, 1)
    colnames(sc_fac) <- "seasonal factor"
    normSf <- function(x, Log) {
        x - mean(x, na.rm = TRUE) + ifelse(Log, 1, 0)
    }
    original_desc <- Descaler(o_fc_xts, Log = Log, y = NA)
    s1_fac <- normSf(Descaler(s1_fac, Log = Log, y = NA), Log = Log)
    colnames(s1_fac) <- "s1_fac"
    k1_fac <- normSf(Descaler(Scaler(original_desc, Log = Log) - 
        Scaler(k1_only, Log = Log), Log = Log, y = NA), Log = Log)
    s2_fac <- normSf(Descaler(Scaler(original_desc, Log = Log) - 
        Scaler(s2_only, Log = Log), Log = Log, y = NA), Log = Log)
    s3_fac <- normSf(Descaler(Scaler(original_desc, Log = Log) - 
        Scaler(s3_only, Log = Log), Log = Log, y = NA), Log = Log)
    if (progressBar) {
        utils::setTxtProgressBar(pb, 19/21, label = "Creating final output")
    }
    original <- Descaler(o_fc_xts, Log = Log, y = NA)
    colnames(original) <- "original series"
    original <- original - as.numeric(utils::head(original, 1)) + 
        ifelse(is.na(as.numeric(utils::head(Euro400, 1))), as.numeric(utils::head(original, 
            1)), as.numeric(utils::head(Euro400, 1)))
    final_sa <- Descaler(s_final_xts, Log = Log, y = NA)
    colnames(final_sa) <- "final sa series"
    if (feb29 == "sfac" | feb29 == "scfac" | feb29 == 
        "sc_fac") {
        sc_fac[format(zoo::index(sc_fac), "%m-%d") == "02-29"] <- NA
        sc_fac <- zoo::na.spline(sc_fac)
        final_sa[format(zoo::index(final_sa), "%m-%d") == 
            "02-29"] <- Descaler(Scaler(original[format(zoo::index(original), 
            "%m-%d") == "02-29"], Log = Log) - Scaler(sc_fac[format(zoo::index(sc_fac), 
            "%m-%d") == "02-29"], Log = Log), Log = Log, 
            y = NA) * ifelse(Log, 100, 1)
    }
    if (feb29 == "sa") {
        final_sa[format(zoo::index(final_sa), "%m-%d") == 
            "02-29"] <- NA
        final_sa <- zoo::na.spline(final_sa)
        sc_fac[format(zoo::index(sc_fac), "%m-%d") == "02-29"] <- Descaler(Scaler(original[format(zoo::index(original), 
            "%m-%d") == "02-29"], Log = Log) - Scaler(final_sa[format(zoo::index(final_sa), 
            "%m-%d") == "02-29"], Log = Log), Log = Log, 
            y = NA) * ifelse(Log, 100, 1)
    }
    trend <- Descaler(trend, Log = Log, y = NA)
    colnames(trend) <- "final trend series"
    fourier_terms <- which.min(aicc400)
    reg <- model_aicc_E400
    if (max(abs(series), na.rm = TRUE) > 1e+05 & !Log) {
        sc_fac <- sc_fac * scaler
        original <- original * scaler
        final_sa <- final_sa * scaler
        trend <- trend * scaler
        s1_complete <- s1_complete * scaler
        s2_complete <- s2_complete * scaler
        k1_complete <- k1_complete * scaler
        s1_only <- s1_only * scaler
        s2_only <- s2_only * scaler
        k1_only <- k1_only * scaler
        s3_only <- s3_only * scaler
        s1_fac <- s1_fac * scaler
        s2_fac <- s2_fac * scaler
        k1_fac <- k1_fac * scaler
        s3_fac <- s3_fac * scaler
        stl_1$time.series <- stl_1$time.series * scaler
        stl_2$time.series <- stl_2$time.series * scaler
        stl_3$time.series <- stl_3$time.series * scaler
    }
    sfac_result <- xts::merge.xts(s1_fac, k1_fac, s2_fac, s3_fac)
    colnames(sfac_result) <- c("sfac1", "cal_fac", 
        "sfac2", "sfac3")
    sfac_result <<- sfac_result
    original <<- original
    final_sa <<- final_sa
    sfac_result[format(zoo::index(sfac_result), "%m-%d") == 
        "02-29", 2:3] <- 0
    sfac_result[format(zoo::index(sfac_result), "%m-%d") == 
        "02-29", 4] <- Descaler(Scaler(original[format(zoo::index(original), 
        "%m-%d") == "02-29"], Log = Log) - Scaler(final_sa[format(zoo::index(final_sa), 
        "%m-%d") == "02-29"], Log = Log) - Scaler(sfac_result[format(zoo::index(sfac_result), 
        "%m-%d") == "02-29", 1], Log = Log), Log = Log, 
        y = NA)
    sa_result <- xts::merge.xts(s1_complete, k1_complete, s2_complete, 
        final_sa)
    colnames(sa_result) <- c("SA1", "cal_adj", "SA2", 
        "SA3")
    sa_result2 <- xts::merge.xts(s1_only, k1_only, s2_only, s3_only)
    colnames(sa_result2) <- c("onlyS1", "onlyCal", 
        "onlyS2", "onlyS3")
    x1 <- stl1_E400$time.series
    x2 <- stl2_E400$time.series
    x3 <- stl3_E400$time.series
    b1 <- as.numeric(xts::first(Euro400_7))
    c2 <- s1_ts
    info <- c(ifelse(Log, "Log", "Level"), Diff, 
        h)
    output <- zoo::na.locf(xts::merge.xts(final_sa, original, 
        sc_fac, trend))
    names(output) <- c("seas_adj", "original", "sc_fac", 
        "trend")
    finout <- list(output = output, fourier_terms = fourier_terms, 
        reg = reg, info = info, stl = list(stl_1, stl_2, stl_3), 
        outlier = ol, sa_result = sa_result, sa_result2 = sa_result2, 
        sfac_result = sfac_result)
    class(finout) <- "daily"
    if (progressBar) {
        utils::setTxtProgressBar(pb, 21/21, label = "Done")
        close(pb)
    }
    if (cval_new > cval & !inherits(ol, "error")) {
        message(paste("The critical value for outlier adjustment has automatically been set to", 
            cval_new))
    }
    return(finout)
}




#' @title DSA
#' @name DSA
#'
#' @description Used to call the module DSA 
#' 
#' @param dsa(series,span.start,model,Log,Diff,automodel,ic,fourier_number,s.window1,s.window2,s.window3,t.window1,t.window2,t.window3,cval,robust1,robust2,robust3,regressor,forecast_regressor,reg.create,reg.dummy,outlier.types,modelspan,feb29,trend_month,outer3,inner3,h,reiterate3,scaler,progressBar)
#' 
#' @details 
#' \itemize{
#'  \item series
#' } 
#'
#' @return 
#' \itemize{
#'  \item output
#'  \item sa_result
#'  \item sa_result2
#' }
#'
#' @author Brazilian Electric Power Research Center - CEPEL
#'
#'
#'
#' @export 
dsa<-function (series, span.start = NA, model = NULL, Log = FALSE, 
               Diff = 0, automodel = "reduced", ic = "bic", 
               fourier_number = NA, s.window1 = 151, s.window2 = 51, s.window3 = 15, 
               t.window1 = NULL, t.window2 = NULL, t.window3 = NULL, cval = 7, 
               robust1 = TRUE, robust2 = TRUE, robust3 = TRUE, regressor = NULL, 
               forecast_regressor = NULL, reg.create = NULL, reg.dummy = NULL, 
               outlier.types = c("AO", "LS", "TC"), modelspan = NULL, 
               feb29 = "sfac", trend_month = 3, outer3 = NULL, inner3 = NULL, 
               h = 365, reiterate3 = NULL, scaler = 1e+07, progressBar = TRUE) 
{
  if (min(series, na.rm = TRUE) <= 0 & Log) {
    stop("Series contains non-positive values. Only positive values allowed for multiplicative time series model. Set Log=FALSE")
  }
  if (h >= 10 & h%%365 != 0) {
    warning("Forecast horizon h should be smaller than 10 or a multiple of 365. Might give problems if specification contains holiday regressors")
  }
  if (h < 10 & h > 0) {
    h <- h * 365
  }
  if (max(abs(series), na.rm = TRUE) > 1e+05 & !Log) {
    Euro400 <- series/scaler
  } else {
    Euro400 <- series
  }
  times <- as.POSIXlt(seq.Date(from = as.Date(xts::first(zoo::index(Euro400))), 
                               to = as.Date(xts::last(zoo::index(Euro400))), by = "days"))
  attr(times, "tzone") <- "GMT"
  attr(zoo::index(Euro400), "tzone") <- "GMT"
  times <- round(times, "days")
  Fill <- xts::xts(rep(NA, times = length(times)), order.by = times)
  Euro400 <- xts::merge.xts(Fill, Euro400)[, 2]
  if (progressBar) {
    total <- 1
    pb <- utils::txtProgressBar(title = "Seasonal adjustment of Daily Data", 
                                min = 0, max = total, width = NA, label = "Configuring data", 
                                style = 3)
    utils::setTxtProgressBar(pb, 1/21, title = "Seasonal adjustment of Daily Data", 
                             label = "Configuring data")
  }
  if (is.na(span.start)) {
    span.start = stats::start(Euro400)
  }
  startingvalue <- suppressWarnings(c(as.integer(format(xts::first(zoo::index(Euro400[paste(span.start, 
                                                                                            "/", sep = "")])), "%Y")), timeDate::dayOfYear(timeDate::timeDate(xts::first(zoo::index(Euro400[paste(span.start, 
                                                                                                                                                                                                  "/", sep = "")])), "%Y-%m-%d") + 13000)))
  if (progressBar) {
    utils::setTxtProgressBar(pb, 2/21, label = "Estimating Day-of-the-Week")
  }
  Euro400 <- zoo::na.locf(Euro400)
  Euro400_7 <- stats::ts(as.numeric(Scaler(Euro400[paste(span.start, 
                                                         "/", sep = "")], Diff = Diff, Log = Log)), 
                         frequency = 7, start = startingvalue)
  stl_1 <- stats::stl(Euro400_7, s.window = s.window1, robust = robust1, 
                      t.window = t.window1)
  stl1_E400 <- stl_1
  v1 = stl_1$time.series[, 2] + stl_1$time.series[, 3]
  s1 <- Descaler(v1, Diff = Diff, y = Euro400[paste(span.start, 
                                                    sep = "")])
  s1 <- s1 - mean(s1) + mean(Scaler(Euro400, Log = Log))
  times <- as.POSIXlt(seq.Date(from = as.Date(xts::first(zoo::index(Euro400))), 
                               to = as.Date(xts::last(zoo::index(Euro400))), by = "days"))
  s1_xts <- xts::xts(s1, order.by = xts::last(times, n = length(s1)))
  s1_xts[format(zoo::index(s1_xts), "%m-%d") == "02-29"] <- NA
  s1_xts <- stats::na.omit(s1_xts)
  sstart <- c(as.integer(format(zoo::index(s1_xts)[1], "%Y")), 
              as.integer(timeDate::dayOfYear(timeDate::timeDate(zoo::index(s1_xts[1])))))
  sstart[2] <- min(365, sstart[2])
  s1_ts <- stats::ts(s1_xts, start = sstart, freq = 365)[, 
                                                         1]
  if (is.null(reg.dummy)) {
    hol <- makeCal(holidays = reg.create, h = h, original = s1_xts, 
                   original2 = s1_ts)
  } else {
    hol <- makeDummy(holidays = reg.create, from = reg.dummy[1], 
                     to = reg.dummy[2], h = h, original = s1_xts, original2 = s1_ts)
  }
  if (!is.null(modelspan)) {
    keep_s1_ts <- s1_ts
    s1_ts <- stats::window(s1_ts, start = c(stats::end(s1_ts)[1] - 
                                              modelspan, stats::end(s1_ts)[2]), end = stats::end(s1_ts))
    keep_s1_xts <- s1_xts
    s1_xts <- ts2xts(s1_ts)
    keep_regressor <- regressor
    ll <- length(s1_ts)
    ll2 <- length(keep_s1_ts)
    regressor <- regressor[(ll2 - ll + 1):length(s1_ts)]
    if (is.null(reg.dummy)) {
      keep_hol <- hol
      hol <- makeCal(holidays = reg.create, h = h, original = s1_xts, 
                     original2 = s1_ts)
    } else {
      keep_hol <- hol
      hol <- makeDummy(holidays = reg.create, from = reg.dummy[1], 
                       to = reg.dummy[2], h = h, original = s1_xts, 
                       original2 = s1_ts)
    }
  }
  aicc400 <- aicc400_2 <- bic400 <- rep(NA, times = 30)
  if (!is.null(model)) {
    if (progressBar) {
      utils::setTxtProgressBar(pb, 5/21, label = "Estimating preliminary ARIMA model")
    }
    automodel = NULL
    s_arima365_prior = data.frame(arma = rep(0, 6))
    s_arima365_prior$arma[1] = model[1]
    s_arima365_prior$arma[6] = model[2]
    s_arima365_prior$arma[2] = model[3]
  }
  if (!is.null(automodel)) {
    if (progressBar) {
      utils::setTxtProgressBar(pb, 6/21, label = "Estimating prelimary automatic ARIMA model")
    }
    if (substr(automodel, 1, 1) == "r") {
      s_arima365_prior <- tryCatch(forecast::auto.arima(s1_ts, 
                                                        stepwise = TRUE, max.d = 1, seasonal = F, ic = ic, 
                                                        xreg = cbind(forecast::fourier(s1_ts, 24)[, c(1:10, 
                                                                                                      c(23:24, 47:48))], hol$mhol, regressor)), error = function(e) e)
      if (inherits(s_arima365_prior, "error")) {
        s_arima365_prior$arma[1] <- 1
        s_arima365_prior$arma[6] <- 1
        s_arima365_prior$arma[2] <- 0
      }
    }
    if (substr(automodel, 1, 1) == "f") {
      s_arima365_prior <- tryCatch(forecast::auto.arima(s1_ts, 
                                                        stepwise = TRUE, max.d = 1, seasonal = F, ic = ic, 
                                                        xreg = cbind(forecast::fourier(s1_ts, 24), hol$mhol, 
                                                                     regressor)), error = function(e) e)
      if (inherits(s_arima365_prior, "error")) {
        s_arima365_prior$arma[1] <- 1
        s_arima365_prior$arma[6] <- 1
        s_arima365_prior$arma[2] <- 0
      }
    }
  }
  if (is.na(fourier_number)) {
    for (j in 1:30) {
      a3 <- tryCatch(forecast::Arima(s1_ts, order = c(s_arima365_prior$arma[1], 
                                                      s_arima365_prior$arma[6], s_arima365_prior$arma[2]), 
                                     xreg = cbind(forecast::fourier(s1_ts, j), hol$mhol, 
                                                  regressor), method = "ML"), error = function(e) e)
      if (inherits(a3, "error")) {
        next
      }
      aicc400[j] <- a3$aicc
    }
  } else {
    aicc400 <- rep(NA, times = 30)
    aicc400[fourier_number] <- 5
  }
  if (length(aicc400[!is.na(aicc400)]) == 0) {
    aicc400[24] <- 4.3391883295
  }
  s_arima365 <- forecast::Arima(s1_ts, order = c(s_arima365_prior$arma[1], 
                                                 s_arima365_prior$arma[6], s_arima365_prior$arma[2]), 
                                xreg = cbind(forecast::fourier(s1_ts, which.min(aicc400)), 
                                             hol$mhol, regressor), method = "ML")
  if (progressBar) {
    utils::setTxtProgressBar(pb, 8/21, label = "Outlier Detection")
  }
  cval_new <- cval
  ol <- tryCatch(suppressWarnings(outlier(series = s1_ts, model = s_arima365, 
                                          cval = cval, types = outlier.types, holidays = cbind(hol$mhol, 
                                                                                               regressor), number.fourier = which.min(aicc400))), 
                 error = function(e) e)
  if (inherits(ol, "error")) {
    cval_new <- cval_new + 1
    ol <- tryCatch(suppressWarnings(outlier(series = s1_ts, 
                                            model = s_arima365, cval = cval_new, types = outlier.types, 
                                            holidays = cbind(hol$mhol, regressor), number.fourier = which.min(aicc400))), 
                   error = function(e) e)
  }
  if (inherits(ol, "error")) {
    cval_new <- cval_new + 1
    ol <- tryCatch(suppressWarnings(outlier(series = s1_ts, 
                                            model = s_arima365, cval = cval_new, types = outlier.types, 
                                            holidays = cbind(hol$mhol, regressor), number.fourier = which.min(aicc400))), 
                   error = function(e) e)
  }
  if (inherits(ol, "error")) {
    s1_ol <- s1_ts
    outlier_effect <- rep(0, length(s1_ol))
  }
  if (!inherits(ol, "error")) {
    s1_ol <- ol$series_adj
    outlier_effect <- ol$outlier_eff
  }
  if (progressBar) {
    utils::setTxtProgressBar(pb, 14/21, label = "Estimating calendar effects")
  }
  
  # CEPEL 2 agosto 2020
  xregBR = cbind(forecast::fourier(s1_ts,which.min(aicc400)), hol$mhol, regressor)
  colnames(xregBR)<-colnames(cbind(forecast::fourier(s1_ts,which.min(aicc400), h = h), hol$lhol, forecast_regressor))
  # CEPEL 2 agosto 2020
  
  arima_reg365 <- forecast::Arima(s1_ol, order = c(s_arima365$arma[1], 
                                                   s_arima365$arma[6], s_arima365$arma[2]), xreg = xregBR, method = "ML", 
                                  include.constant = TRUE)
  model_aicc_E400 <- arima_reg365
  arima_reg365 <<- arima_reg365
  h <<- h
  s1_ts <<- s1_ts
  aicc400 <<- aicc400
  hol <<- hol
  forecast_regressor <<- forecast_regressor
  fc1 <- forecast::forecast(arima_reg365, h = h, xreg = cbind(forecast::fourier(s1_ts, 
                                                                                which.min(aicc400), h = h), hol$lhol, forecast_regressor))
  if (!is.null(modelspan)) {
    firstpart <- keep_s1_ts[1:(length(keep_s1_ts) - length(s1_ts))]
    s1_fc <- stats::ts(c(firstpart, fc1$model$x, fc1$mean), 
                       start = stats::start(keep_s1_ts), frequency = 365)
    hol <- keep_hol
    regressor <- keep_regressor
    s1_xts <- keep_s1_xts
    s1_ts <- keep_s1_ts
  } else {
    s1_fc <- stats::ts(c(fc1$model$x, fc1$mean), start = stats::start(s1_ts), 
                       frequency = 365)
  }
  if (!is.null(reg.create)) {
    if (is.null(dim(hol$mhol))) {
      cf <- ((model_aicc_E400$coef[grep("hol", names(model_aicc_E400$coef))]) * 
               (c(hol$mhol, hol$lhol)))
    } else {
      cf <- rep(0, times = (dim(hol$mhol)[1] + dim(hol$lhol)[1]))
      for (k in 1:dim(hol$mhol)[2]) {
        cf <- cf + ((model_aicc_E400$coef[grep("hol", 
                                               names(model_aicc_E400$coef))][k]) * (rbind(hol$mhol, 
                                                                                          hol$lhol)[, k]))
      }
    }
    k1 <- s1_fc - cf
  } else {
    k1 <- s1_fc
  }
  if (!is.null(regressor)) {
    if (is.null(dim(as.data.frame(regressor)))) {
      cf <- ((model_aicc_E400$coef[length(model_aicc_E400$coef)]) * 
               (c(regressor, forecast_regressor)))
    } else {
      cf <- 0
      for (k in 1:dim(as.data.frame(regressor))[2]) {
        cf <- cf + ((model_aicc_E400$coef[(length(model_aicc_E400$coef) + 
                                             1 - dim(as.data.frame(regressor))[2]):length(model_aicc_E400$coef)][k]) * 
                      (rbind(matrix(regressor, nrow = nrow(data.frame(regressor))), 
                             matrix(forecast_regressor, nrow = nrow(data.frame(forecast_regressor))))[, 
                                                                                                      k]))
      }
    }
    k1 <- k1 - cf
  } else {
    k1 <- k1
  }
  if (progressBar) {
    utils::setTxtProgressBar(pb, 15/21, label = "Estimating Day-Of-Month Effect")
  }
  k1_xts <- ts2xts(k1)
  k1_complete <- k1_xts
  k1_31 <- fill31(k1_xts, fill = "spline")
  k1x <- stats::ts(Scaler(k1_31, Diff = Diff), frequency = 31)
  stl_2 <- stats::stl(k1x, s.window = s.window2, robust = robust2, 
                      t.window = t.window2)
  stl2_E400 <- stl_2
  s2_31 <- stats::ts(as.numeric(Descaler(stl_2$time.series[, 
                                                           2] + stl_2$time.series[, 3], Diff = Diff, y = ts2xts(s1_ts))), 
                     start = stats::start(k1_31), freq = 372)
  s2 <- s2_31 - mean(s2_31) + mean(k1_31)
  s2 <- drop31(s2, new_start = stats::start(k1)[2], new_end = stats::end(k1)[2])
  s2_complete <- s2
  s2 <- xts2ts(s2, freq = 365)
  if (progressBar) {
    utils::setTxtProgressBar(pb, 16/21, label = "Estimating Day-Of-Year Effect")
  }
  if (is.null(outer3)) {
    outerval = if (robust3) 
      15
    else 0
  } else {
    outerval = outer3
  }
  if (is.null(inner3)) {
    innerval = if (robust3) 
      1
    else 2
  }  else {
    innerval = inner3
  }
  s2x <- Scaler(s2, Diff = Diff)
  stl_3 <- stats::stl(s2x, s.window = s.window3, robust = robust3, 
                      outer = outerval, inner = innerval, t.window = t.window3)
  s3 <- stats::ts(as.numeric(Descaler(stl_3$time.series[, 2] + 
                                        stl_3$time.series[, 3], y = ts2xts(s1_ts), Diff = Diff)), 
                  start = startingvalue, frequency = 365)
  if (!is.null(reiterate3)) {
    for (i in 1:reiterate3) {
      s3 <- Scaler(s3, Diff = Diff)
      stl_3 <- stats::stl(s3, s.window = s.window3, robust = robust3, 
                          outer = outerval, inner = innerval, t.window = t.window3)
      s3 <- stats::ts(as.numeric(Descaler(stl_3$time.series[, 
                                                            2] + stl_3$time.series[, 3], y = ts2xts(s1_ts), 
                                          Diff = Diff)), start = startingvalue, frequency = 365)
    }
  }
  s3_E400 <- s3
  stl3_E400 <- stl_3
  if (progressBar) {
    utils::setTxtProgressBar(pb, 16/21, label = "Preparing set of final time series")
  }
  s_final <- s3 + c(outlier_effect, rep(xts::last(outlier_effect), 
                                        times = (length(s3) - length(outlier_effect))))
  outlier_effect_xts <- ts2xts(s_final - s3)
  times <- as.POSIXlt(seq.Date(from = as.Date(xts::first(zoo::index(Euro400))), 
                               to = as.Date(xts::last(zoo::index(Euro400))) + h, by = "days"))
  attr(times, "tzone") <- "GMT"
  attr(zoo::index(Euro400), "tzone") <- "GMT"
  Fill <- xts::xts(rep(NA, times = length(times)), order.by = times)
  s_final_xts <- suppressWarnings(zoo::na.spline(xts::merge.xts(a = ts2xts(s_final), 
                                                                Fill)$a[paste(span.start, "/", sep = "")]))
  n_t = ceiling(365/(12/trend_month))
  if (n_t - n_t%/%2 * 2 == 0) {
    n_t <- n_t + 1
  }
  fraction = n_t/length(s_final_xts)
  trend_xts <- xts::xts(stats::predict(stats::loess(s_final_xts ~ 
                                                      seq.int(length(s_final_xts)), span = fraction), newdata = seq.int(length(s_final_xts))), 
                        order.by = zoo::index(s_final_xts))
  times <- as.POSIXlt(seq.Date(from = as.Date(xts::first(zoo::index(Euro400))), 
                               to = as.Date(xts::last(zoo::index(Euro400))) + h, by = "days"))
  attr(times, "tzone") <- "GMT"
  attr(zoo::index(Euro400), "tzone") <- "GMT"
  Fill <- xts::xts(rep(NA, times = length(times)), order.by = times)
  Fill <- Fill[paste(xts::first(zoo::index(s1_xts)), "/", 
                     sep = "")]
  s1_x <- ts2xts(s1_fc)
  s1_x <- xts::merge.xts(s1_x, Fill)$s1_x
  outlier_effect2 <- stats::ts(suppressWarnings(as.numeric(outlier_effect)), 
                               start = stats::start(s1_ts), freq = 365)
  outliers <- ts2xts(outlier_effect2)
  outliers <- xts::merge.xts(outliers, Fill)$outliers
  outliers[is.na(outliers)] <- xts::last(outliers[!is.na(outliers)])
  sf_x <- day_split(stl_1$time.series[, 1], use = "ets", 
                    h = h)$sf
  times <- as.POSIXlt(seq.Date(from = as.Date(xts::first(zoo::index(s1_xts))), 
                               length.out = length(sf_x), by = "days"))
  attr(times, "tzone") <- "GMT"
  attr(zoo::index(Euro400), "tzone") <- "GMT"
  sf_x_xts <- xts::xts(sf_x, order.by = times)
  times <- as.POSIXlt(seq.Date(from = as.Date(xts::first(zoo::index(s1_xts))), 
                               length.out = length(sf_x) + 1, by = "days"))
  comp <- Scaler(Euro400[paste(xts::first(zoo::index(s1_x)), 
                               "/", sep = "")], Log = Log) - as.numeric(xts::first(s1_x)) - 
    as.numeric(xts::first(outliers))
  s1_fac <- Descaler(xts::xts(sf_x, order.by = seq.Date(as.Date(stats::start(comp)), 
                                                        length.out = length(sf_x), by = "days")), Diff = Diff, 
                     y = comp)
  original_forecast <- s1_x + outliers + s1_fac
  s1_complete <- original_forecast - s1_fac
  o_fc_xts <- fill_up(original_forecast, Scaler(Euro400, Log = Log))
  s_final_xts <- s_final_xts - mean(xts::first(s_final_xts, 
                                               length(s_final_xts) - h), na.rm = TRUE) + mean(xts::first(o_fc_xts, 
                                                                                                         length(o_fc_xts) - h), na.rm = TRUE)
  s1_complete <- Descaler(s1_complete - mean(xts::first(s1_complete, 
                                                        length(s_final_xts) - h), na.rm = TRUE) + mean(xts::first(o_fc_xts, 
                                                                                                                  length(o_fc_xts) - h), na.rm = TRUE), Log = Log, y = NA)
  k1_complete <- k1_complete + outlier_effect_xts
  k1_complete <- Descaler(k1_complete - mean(xts::first(k1_complete, 
                                                        length(s_final_xts) - h), na.rm = TRUE) + mean(xts::first(o_fc_xts, 
                                                                                                                  length(o_fc_xts) - h), na.rm = TRUE), Log = Log, y = NA)
  s2_complete <- s2_complete + outlier_effect_xts
  s2_complete <- Descaler(s2_complete - mean(xts::first(s2_complete, 
                                                        length(s_final_xts) - h), na.rm = TRUE) + mean(xts::first(o_fc_xts, 
                                                                                                                  length(o_fc_xts) - h), na.rm = TRUE), Log = Log, y = NA)
  s1_only <- s1_complete
  g <- Descaler(Scaler(s1_complete, Log = Log) - Scaler(k1_complete, 
                                                        Log = Log), Log = Log, y = NA)
  v <- Descaler(o_fc_xts, Log = Log, y = NA)
  k1_only <- Descaler(Scaler(v, Log = Log) - Scaler(g, Log = Log), 
                      Log = Log, y = NA)
  k1_only <- k1_only - mean(xts::first(k1_only, length(k1_only) - 
                                         h), na.rm = TRUE) + mean(xts::first(Descaler(o_fc_xts, 
                                                                                      Log = Log, y = NA), length(k1_only) - h), na.rm = TRUE)
  g <- Descaler(Scaler(k1_complete, Log = Log) - Scaler(s2_complete, 
                                                        Log = Log), Log = Log, y = NA)
  v <- Descaler(o_fc_xts, Log = Log, y = NA)
  s2_only <- Descaler(Scaler(v, Log = Log) - Scaler(g, Log = Log), 
                      Log = Log, y = NA)
  s2_only <- s2_only - mean(xts::first(s2_only, length(s2_only) - 
                                         h), na.rm = TRUE) + mean(xts::first(Descaler(o_fc_xts, 
                                                                                      Log = Log, y = NA), length(s2_only) - h), na.rm = TRUE)
  g <- Descaler(Scaler(s2_complete, Log = Log) - s_final_xts, 
                Log = Log, y = NA)
  v <- Descaler(o_fc_xts, Log = Log, y = NA)
  s3_only <- Descaler(Scaler(v, Log = Log) - Scaler(g, Log = Log), 
                      Log = Log, y = NA)
  s3_only <- s3_only - mean(xts::first(s3_only, length(s3_only) - 
                                         h), na.rm = TRUE) + mean(xts::first(Descaler(o_fc_xts, 
                                                                                      Log = Log, y = NA), length(s3_only) - h), na.rm = TRUE)
  trend <- trend_xts - mean(xts::first(trend_xts, length(trend_xts) - 
                                         h), na.rm = TRUE) + mean(xts::first(o_fc_xts, length(o_fc_xts) - 
                                                                               h), na.rm = TRUE)
  sc_fac <- Descaler(o_fc_xts - s_final_xts, Log = Log, y = NA) * 
    ifelse(Log, 100, 1)
  colnames(sc_fac) <- "seasonal factor"
  normSf <- function(x, Log) {
    x - mean(x, na.rm = TRUE) + ifelse(Log, 1, 0)
  }
  original_desc <- Descaler(o_fc_xts, Log = Log, y = NA)
  s1_fac <- normSf(Descaler(s1_fac, Log = Log, y = NA), Log = Log)
  colnames(s1_fac) <- "s1_fac"
  k1_fac <- normSf(Descaler(Scaler(original_desc, Log = Log) - 
                              Scaler(k1_only, Log = Log), Log = Log, y = NA), Log = Log)
  s2_fac <- normSf(Descaler(Scaler(original_desc, Log = Log) - 
                              Scaler(s2_only, Log = Log), Log = Log, y = NA), Log = Log)
  s3_fac <- normSf(Descaler(Scaler(original_desc, Log = Log) - 
                              Scaler(s3_only, Log = Log), Log = Log, y = NA), Log = Log)
  if (progressBar) {
    utils::setTxtProgressBar(pb, 19/21, label = "Creating final output")
  }
  original <- Descaler(o_fc_xts, Log = Log, y = NA)
  colnames(original) <- "original series"
  original <- original - as.numeric(utils::head(original, 1)) + 
    ifelse(is.na(as.numeric(utils::head(Euro400, 1))), as.numeric(utils::head(original, 
                                                                              1)), as.numeric(utils::head(Euro400, 1)))
  final_sa <- Descaler(s_final_xts, Log = Log, y = NA)
  colnames(final_sa) <- "final sa series"
  if (feb29 == "sfac" | feb29 == "scfac" | feb29 == 
      "sc_fac") {
    sc_fac[format(zoo::index(sc_fac), "%m-%d") == "02-29"] <- NA
    sc_fac <- zoo::na.spline(sc_fac)
    final_sa[format(zoo::index(final_sa), "%m-%d") == 
               "02-29"] <- Descaler(Scaler(original[format(zoo::index(original), 
                                                           "%m-%d") == "02-29"], Log = Log) - Scaler(sc_fac[format(zoo::index(sc_fac), 
                                                                                                                   "%m-%d") == "02-29"], Log = Log), Log = Log, 
                                    y = NA) * ifelse(Log, 100, 1)
  }
  if (feb29 == "sa") {
    final_sa[format(zoo::index(final_sa), "%m-%d") == 
               "02-29"] <- NA
    final_sa <- zoo::na.spline(final_sa)
    sc_fac[format(zoo::index(sc_fac), "%m-%d") == "02-29"] <- Descaler(Scaler(original[format(zoo::index(original), 
                                                                                              "%m-%d") == "02-29"], Log = Log) - Scaler(final_sa[format(zoo::index(final_sa), 
                                                                                                                                                        "%m-%d") == "02-29"], Log = Log), Log = Log, 
                                                                       y = NA) * ifelse(Log, 100, 1)
  }
  trend <- Descaler(trend, Log = Log, y = NA)
  colnames(trend) <- "final trend series"
  fourier_terms <- which.min(aicc400)
  reg <- model_aicc_E400
  if (max(abs(series), na.rm = TRUE) > 1e+05 & !Log) {
    sc_fac <- sc_fac * scaler
    original <- original * scaler
    final_sa <- final_sa * scaler
    trend <- trend * scaler
    s1_complete <- s1_complete * scaler
    s2_complete <- s2_complete * scaler
    k1_complete <- k1_complete * scaler
    s1_only <- s1_only * scaler
    s2_only <- s2_only * scaler
    k1_only <- k1_only * scaler
    s3_only <- s3_only * scaler
    s1_fac <- s1_fac * scaler
    s2_fac <- s2_fac * scaler
    k1_fac <- k1_fac * scaler
    s3_fac <- s3_fac * scaler
    stl_1$time.series <- stl_1$time.series * scaler
    stl_2$time.series <- stl_2$time.series * scaler
    stl_3$time.series <- stl_3$time.series * scaler
  }
  sfac_result <- xts::merge.xts(s1_fac, k1_fac, s2_fac, s3_fac)
  colnames(sfac_result) <- c("sfac1", "cal_fac", 
                             "sfac2", "sfac3")
  sfac_result <<- sfac_result
  original <<- original
  final_sa <<- final_sa
  sfac_result[format(zoo::index(sfac_result), "%m-%d") == 
                "02-29", 2:3] <- 0
  sfac_result[format(zoo::index(sfac_result), "%m-%d") == 
                "02-29", 4] <- Descaler(Scaler(original[format(zoo::index(original), 
                                                               "%m-%d") == "02-29"], Log = Log) - Scaler(final_sa[format(zoo::index(final_sa), 
                                                                                                                         "%m-%d") == "02-29"], Log = Log) - Scaler(sfac_result[format(zoo::index(sfac_result), 
                                                                                                                                                                                      "%m-%d") == "02-29", 1], Log = Log), Log = Log, 
                                        y = NA)
  sa_result <- xts::merge.xts(s1_complete, k1_complete, s2_complete, 
                              final_sa)
  colnames(sa_result) <- c("SA1", "cal_adj", "SA2", 
                           "SA3")
  sa_result2 <- xts::merge.xts(s1_only, k1_only, s2_only, s3_only)
  colnames(sa_result2) <- c("onlyS1", "onlyCal", 
                            "onlyS2", "onlyS3")
  x1 <- stl1_E400$time.series
  x2 <- stl2_E400$time.series
  x3 <- stl3_E400$time.series
  b1 <- as.numeric(xts::first(Euro400_7))
  c2 <- s1_ts
  info <- c(ifelse(Log, "Log", "Level"), Diff, 
            h)
  output <- zoo::na.locf(xts::merge.xts(final_sa, original, 
                                        sc_fac, trend))
  names(output) <- c("seas_adj", "original", "sc_fac", 
                     "trend")
  finout <- list(output = output, fourier_terms = fourier_terms, 
                 reg = reg, info = info, stl = list(stl_1, stl_2, stl_3), 
                 outlier = ol, sa_result = sa_result, sa_result2 = sa_result2, 
                 sfac_result = sfac_result)
  class(finout) <- "daily"
  if (progressBar) {
    utils::setTxtProgressBar(pb, 21/21, label = "Done")
    close(pb)
  }
  if (cval_new > cval & !inherits(ol, "error")) {
    message(paste("The critical value for outlier adjustment has automatically been set to", 
                  cval_new))
  }
  return(finout)
}

#' @title Programa cargaajustada	
#' @name cargaajustada
#'
#' @description executa programa carga ajustada
#' 
#' @param (prefixo,caminho,caminhosaida,datasajuste,dsamodel,dsafourier,dsawindow,dsalog)
#' 
#' @details 
#'
#'
#' @return carga ajustada e taxa de crescimento
#'
#' @author CEPEL
#'
#'
#'
#' @export 
cargaajustada <-function(prefixo,caminho,caminhoSaida=caminho,datasel1=c(0,0),dsamodel='Automatico',dsafourier=25,
                       dsawindow=21,dsalog=FALSE){
  
  
  list.of.packages <- c("lubridate",'stringr','dynlm','e1071','timeDate','xts','dsa',
                        'tools','DT','forecast')
  new.packages <- list.of.packages[!(list.of.packages %in% installed.packages()[,"Package"])]
  if(length(new.packages)) install.packages(new.packages,repos='http://cran.us.r-project.org',dependencies = TRUE)
  
  library(lubridate)
  library(forecast)
  library(stringr)
  library(dynlm)
  library(e1071)
  library(timeDate)
  library(xts)
  library(dsa)
  library(tools)
  library(DT)
  
  #arqconfig
  input=list()
  input[['datasel1']]=datasel1
  input[['dsamodel']]=dsamodel
  input[['dsafourier']]=dsafourier
  input[['dsawindow']]=dsawindow
  input[['dsalog']]=dsalog
  

  session=NULL
  arquivos=0
  #caminho = paste0(currwd, "", collapse = "") # diretorio onde estao os DADOS
  #caminhoSaida = # diretorio onde estao os DADOS
  
  
  versao<<- as.numeric(paste0(R.Version()$major,".",substr(R.Version()$minor,1,1)))
  
  existeplotdsa<<-0
  exec_concluida<<-0
  
  printUI(session, "CEPEL - Programa Carga Ajustada 1.01")
  
  suppressWarnings(rm(lags,config,DADOS,DADOS_FILTRADOS,resultadodsa,tipodiario,abatecarga))
  
  
  
  printUI(session, "Iniciando leitura dos arquivos de entrada...")
  arqcarga=paste0(caminho,"\\",prefixo,"_CARGAHIST.csv")
  arqtemp=paste0(caminho,"\\",prefixo,"_TEMPHIST.csv")
  arqferiado=paste0(caminho,"\\",prefixo,"_FERIADOS.csv")
  #arqverao=paste0(prefixo,"_HORAVERAO.csv")
  arqabatimento=paste0(caminho,"\\",prefixo,"_PERDAS.csv")
  arqprec=paste0(caminho,"\\",prefixo,"_PRECIPITACAO.csv")
  
  
  
  DADOS<<-LEITORA(session,arqcarga,arqtemp,arqferiado,arqabatimento,arqprec) # leitura arquivo de DADOS em formato csv
  #printUI(session, "Arquivos de entrada lidos com sucesso.")
  
  tipodiario<<-DADOS$tipodiario	
  indcarga<<-1
  indferiado<<-2
  indverao<<-3
  indtemp<<-4
  indprec<<-6
  
  if (tipodiario==0){
    indcarga<<-c(1:24)
    indferiado<<-25
    indverao<<-26
    indtemp<<-c(27:50)
  } 
  
  DADOS_FILTRADOS<<-FILTRAGEM(session,DADOS,tipodiario) # FILTRA CARGA E Temperatura
  
  datasel1=c()
  if (input$datasel[1]==0){
    if (length(DADOS$abatecarga)==1) datasel1=rownames(DADOS$DATAHIST)[c(1,length(rownames(DADOS$DATAHIST)))] 
    if (length(DADOS$abatecarga)>1) datasel1=rbind(as.character(datasel1),c(paste0(DADOS$abatecarga[1,1],"-01"),paste0(tail(DADOS$abatecarga,1)[1],"-",days_in_month(paste0(tail(DADOS$abatecarga,1)[1],"-01")))))
    if (length(DADOS_FILTRADOS$PRECIPITACAO)>1) datasel1=rbind(datasel1,c(as.character(DADOS_FILTRADOS$PRECIPITACAO[1,1]),as.character(as.Date(tail(DADOS_FILTRADOS$PRECIPITACAO$datas,1)))))
    if (is.na(datasel1[3])==FALSE) datasel1=c(max(datasel1[,1]),as.character(min(datasel1[,2])))
    if (day(ymd(datasel1[1]))!=1) datasel1[1]= as.character(floor_date(ymd(datasel1[1]) %m+% months(1), 'month'))
    if (day(ymd(datasel1[2]))!=day(ceiling_date(ymd(datasel1[2]) %m-% months(1), 'month') %m-% days(1))) datasel1[2]=as.character(ceiling_date(ymd(datasel1[2]) %m-% months(1), 'month') %m-% days(1))
  }else{	
    
    datasel1=input$datasel[1]
    if ((datasel1[1]==Sys.Date())&&(datasel1[1]==Sys.Date())){
      print("Erro - Selecione o periodo desejado.")
      executar=0
    }
    
    if ((datasel1[1]<rownames(DADOS$DATAHIST)[1])|(datasel1[2]>rownames(DADOS$DATAHIST)[length(rownames(DADOS$DATAHIST))])){
      print(paste0("Erro -",paste('Periodo disponivel: ',rownames(DADOS$DATAHIST)[1]," a ",rownames(DADOS$DATAHIST)[length(rownames(DADOS$DATAHIST))]), type = "error"))
      executar=0
    }
    
    if (datasel1[1]>datasel1[2]) {
      print("Erro - Selecione um periodo valido.")
      executar=0
    }
    
    
  }
  
  
  
  #lags<<-c(input$lag1,input$lag2,input$lag3)
  lags<<-c(7,7,7)
  if (paste(input$dsamodel)=='Automatico') model=NULL
  if (paste(input$dsamodel)!='Automatico') model=as.numeric(strsplit(input$dsamodel,",")[[1]])
  config<-list(log=input$dsalog,model=model,fourier=input$dsafourier,stl=input$dsawindow)
  
  printUI(session,paste0("Periodo dos dados: ",head(rownames(DADOS$DATAHIST),1)," a ",tail(rownames(DADOS$DATAHIST),1)))
  if (length(DADOS$abatecarga)>1){
    printUI(session,paste0("Periodo dos dados de perdas: ",paste0(DADOS$abatecarga[1,1],"-01")," a ",paste0(tail(DADOS$abatecarga,1)[1],"-",days_in_month(paste0(tail(DADOS$abatecarga,1)[1],"-01")))))
  } 
  
  if (length(DADOS_FILTRADOS$PRECIPITACAO)>1){
    printUI(session,paste0("Periodo dos dados de precipitacao: ",as.Date(DADOS_FILTRADOS$PRECIPITACAO[1,1])," a ",as.character(as.Date(tail(DADOS_FILTRADOS$PRECIPITACAO$datas,1)))))
    
  }
  
  
  printUI(session,paste0("Periodo de ajuste: ",datasel1[1]," a ",datasel1[2]))
  # printUI(session,paste0("Lag de Carga: ",lags[1]))
  # printUI(session,paste0("Lag de Temperatura: ",lags[2]))
  # printUI(session,paste0("Lag de Precipitacao: ",lags[3]))
  printUI(session,paste0("Log: ",config$log))
  printUI(session,paste0("Modelo Arima: ",input$dsamodel))
  printUI(session,paste0("Termos Serie Fourier: ",config$fourier))
  printUI(session,paste0("Parametros STL: ",config$stl))
  
  if (tipodiario==1) printUI(session,paste0("Tipo dados de entrada: Diario"))
  if (tipodiario==0) printUI(session,paste0("Tipo dados de entrada: Horario"))
  
  #if (input$chavedsa==TRUE){
  printUI(session,"Executando DSA...")
  
  tryCatch(
    {
      #save(config,file='config.Rdata')
      if (tipodiario==1)  feriados=DADOS$DATAHIST$feriado
      if (tipodiario==0)  feriados=DADOS$DATAHIST$x_feriados
      
      resultadodsa<<-EXECUTADSA(DADOS_FILTRADOS$DATAHIST_FILTRADOS,datasel1,config,DADOS$abatecarga,DADOS_FILTRADOS$PRECIPITACAO,feriados)
      efeito_feriado=resultadodsa$COEFERIADOS # coeficientes de regressao dos feriados
      serie_ajustada_calendario=resultadodsa$SAIDACAL
      
      serie_ajustada_feriado=resultadodsa$SAIDAFER
      
      efeito_temp=resultadodsa$COEFREG
      serie_ajustada_temp=resultadodsa$SAIDATEMP
      serie_ajusada_prec=resultadodsa$SAIDAPREC
      
      datas=as.Date(time(serie_ajustada_calendario))
      serie_ajustada_calendario=serie_ajustada_calendario[which((datas>=datasel1[1])&(datas<=datasel1[2]))]
      #datas=datas[which((datas>=datasel1[1])&(datas<=datasel1[2]))]
      if (tipodiario==0) serie_diaria=apply(DADOS_FILTRADOS$DATAHIST_FILTRADOS[which((rownames(DADOS_FILTRADOS$DATAHIST_FILTRADOS)>=datasel1[1])&(rownames(DADOS_FILTRADOS$DATAHIST_FILTRADOS)<=datasel1[2])),1:24],1,mean)
      if (tipodiario==1) serie_diaria=DADOS_FILTRADOS$DATAHIST[which((rownames(DADOS_FILTRADOS$DATAHIST)>=datasel1[1])&(rownames(DADOS_FILTRADOS$DATAHIST)<=datasel1[2])),1]
      
      
      # saida_dsad=data.frame(time(serie_ajustada_calendario),round(serie_diaria,2),round(as.numeric(serie_ajustada_calendario),2),round(as.numeric(serie_ajustada_temp),2))
      # colnames(saida_dsad)=c('Datas','Carga','Carga_Ajustada_Cal','Carga_Ajustada_Temp')
      # write.table(saida_dsad,paste0(caminho,'/Resultado_DSA_Diario.csv'),sep=';',quote=F,row.names=FALSE)
      
      datas0=seq(ymd(as.Date(datasel1[1])),ymd(as.Date(datasel1[2])),by='1 month')
      datas1=c()
      for (ii in 1:length(datas0)){
        if (month(datas0)[ii]<10) datas1=c(datas1,paste0(year(datas0[ii]),"-0",month(datas0[ii])))
        if (month(datas0)[ii]>=10) datas1=c(datas1,paste0(year(datas0[ii]),"-",month(datas0[ii])))
        
      }
      datas0=datas1
      rm(datas1)
      
      if (length(resultadodsa$MENSALADJPREC)==0) resultadodsa$MENSALADJPREC=rep(0,length(resultadodsa$MENSALOBS))
      saida_dsa=data.frame(datas0,round(resultadodsa$MENSALOBS,2),round(resultadodsa$MENSALCAL,2),round(resultadodsa$MENSALADJ,2),round(resultadodsa$MENSALADJPREC,2),round(resultadodsa$MENSALOBSABATE,2),round(resultadodsa$MENSALADJABATE,2))
      names(saida_dsa)=c('Datas','Carga','Carga_Ajustada_Cal','Carga_Ajustada_Cal_Temp','Carga_Ajustada_Cal_Temp_Prec','Carga_Liquida','Carga_Ajustada_Liquida')
      
      txc_cal=rep(0,12)
      txc_temp=rep(0,12)
      txc_obs=rep(0,12)
      txc_prec=rep(0,nrow(saida_dsa))
      txc_obsliq=rep(0,12)
      txc_adjliq=rep(0,12)
      
      for (i in 13:nrow(saida_dsa)){
        txc_cal[i]=(as.numeric(saida_dsa[i,3])-as.numeric(saida_dsa[i-12,3]))/as.numeric(saida_dsa[i-12,3])
        txc_temp[i]=(saida_dsa[i,4]-saida_dsa[i-12,4])/saida_dsa[i-12,4]
        txc_obs[i]=(as.numeric(saida_dsa[i,2])-as.numeric(saida_dsa[i-12,2]))/as.numeric(saida_dsa[i-12,2])
        if (sum(saida_dsa$Carga_Ajustada_Cal_Temp_Prec)>0) txc_prec[i]=(as.numeric(saida_dsa[i,5])-as.numeric(saida_dsa[i-12,5]))/as.numeric(saida_dsa[i-12,5])
        txc_obsliq[i]=(as.numeric(saida_dsa[i,6])-as.numeric(saida_dsa[i-12,6]))/as.numeric(saida_dsa[i-12,6])
        txc_adjliq[i]=(as.numeric(saida_dsa[i,7])-as.numeric(saida_dsa[i-12,7]))/as.numeric(saida_dsa[i-12,7])
        
      }
      
      txc_cal=round(txc_cal*100,2)
      txc_temp=round(txc_temp*100,2)
      txc_obs=round(txc_obs*100,2)
      txc_prec=round(txc_prec*100,2)
      txc_obsliq=round(txc_obsliq*100,2)
      txc_adjliq=round(txc_adjliq*100,2)
      
      
      txc=data.frame(datas0,txc_obs,txc_cal,txc_temp,txc_prec,txc_obsliq,txc_adjliq)
      names(txc)=c('Datas','Taxa Crescimento Observada','Taxa Crescimento Calendario',
                   'Taxa Crescimento Calendario/Temperatura','Taxa Crescimento Calendario/Temperatura/Precipitacao',
                   'Taxa Crescimento Observada Liquida','Taxa Crescimento Ajustada Liquida')
      
      
      write.table(saida_dsa,paste0(caminhoSaida,'\\Carga_Ajustada_',prefixo,'.csv'),sep=';',quote=F,row.names = F)
      write.table(txc,paste0(caminhoSaida,'\\Carga_Ajustada_taxa_',prefixo,'.csv'),sep=';',quote=F,row.names = F)
      
      
      #write.table(saida_dsa,paste0(caminho,'/Resultado_DSA.csv'),sep=';',quote=F,row.names=FALSE)
      
      statusdsa<<-1
    },
    error=function(cond){
      printUI(session, "Erro na execucao do DSA:")
      printUI(session, cond)
      printUI(session, "FIM")
      return(NA)
    })
  
  
  printUI(session, "Execucao concluida.")
  return(list(cargaajustada=saida_dsa,taxacrescimento=txc))
}



#' @title Programa del_names	
#' @name del_names
#'
#' @description substitui del_names dsa
#' 
#' @param (x)
#' 
#' @details 
#'
#'
#' @return del_names
#'
#' @author CEPEL
#'
#'
#'
#' @export 
del_names <- function(x){ 
  xts::xts(as.numeric(x), zoo::index(x))
}

#' @title Programa to_month	
#' @name to_month
#'
#' @description substitui to_month dsa
#' 
#' @param (x)
#' 
#' @details 
#'
#'
#' @return to_month
#'
#' @author CEPEL
#'
#'
#'
#' @export 
to_month <- function(x, fun=mean, ...){
  ep <- xts::endpoints(x, on="months")
  for (j in 1:ncol(x)){
    outX <- xts::period.apply(x[,j], INDEX=ep, FUN=fun, ...)
    if (exists("out", envir=environment(), inherits=FALSE)) {out <- merge(out, outX)} else {
      out <- outX
    }}
  colnames(out) <- colnames(x)
  zoo::index(out) <- as.Date(zoo::index(out))
  return(out)
}

#' @title Programa multi_xts2ts	
#' @name multi_xts2ts
#'
#' @description substitui multi_xts2ts dsa
#' 
#' @param (x)
#' 
#' @details 
#'
#'
#' @return multi_xts2ts
#'
#' @author CEPEL
#'
#'
#'
#' @export 
multi_xts2ts <- function(x, short=FALSE) {
  if (short) {
    x[format(zoo::index(x), "%m-%d") == "02-29"] <- NA
    out <- na.omit(x)
  } else{
    ref <- dsa::xts2ts(x[,1])
    a <- lapply(1:ncol(x), function(k) as.numeric(dsa::xts2ts(x[,k], 365)))
    out <- as.data.frame(a)
    colnames(out) <- colnames(x)
    out <- ts(out, start=stats::start(ref), frequency=stats::frequency(ref))}
  return(out)
}

# Lag0 <- function(x, Lag) {
# if (Lag>0) y <- zoo::na.fill0(lag(as.vector(x), k=Lag),0)
# if (Lag<0) y <- zoo::na.fill0(lead(as.vector(x), k=Lag),0)
# return(y)
# }


#' @title Programa Lag0	
#' @name Lag0
#'
#' @description substitui Lag0 dsa
#' 
#' @param (x)
#' 
#' @details 
#'
#'
#' @return Lag0
#'
#' @author CEPEL
#'
#'
#'
#' @export 
Lag0 <- function(x, Lag) {
  y <- zoo::na.fill0(lag(x, k=Lag),0)
  return(y)
}


#' @title Programa cross_seasonal	
#' @name cross_seasonal
#'
#' @description substitui cross_seasonal dsa
#' 
#' @param (x)
#' 
#' @details 
#'
#'
#' @return cross_seasonal
#'
#' @author CEPEL
#'
#'
#'
#' @export 
cross_seasonal <- function(reference="12-24", span=14, Day=c("0"), output="ts", y=NULL, from="2000", to="2030") {  
  if(is.null(y)) {
    dates <- seq(as.Date(paste0(as.character(from), "-01-01")),as.Date(paste0(as.character(to), "-12-31")),by="days") 
    y  <- xts::xts(rep(0,length(dates)),order.by=dates)
  }
  time <- seq.Date(from=as.Date(head(zoo::index(y),1)), to=as.Date(tail(zoo::index(y),1)), by="days")
  seriesA <- xts::xts(rep(0, length(time)), time)
  for (j in Day) {seriesA[format(zoo::index(seriesA), "%w")==j] <- 1}
  seriesB <- xts::xts(rep(0, length(time)), time)
  
  timespan <- format(seq.Date(as.Date(paste0("2015-", reference)), by="days", length.out=span), "%m-%d") # Year does not matter
  seriesB[format(zoo::index(seriesB), "%m-%d") %in% timespan] <- 1
  series <- seriesA * seriesB
  
  if (output=="ts"){out <- dsa::xts2ts(series,365)} else {out <- series}
  
  return(out)
}



#' @title Programa split_year_plot	
#' @name split_year_plot
#'
#' @description substitui split_year_plot dsa
#' 
#' @param (x)
#' 
#' @details 
#'
#'
#' @return split_year_plot
#'
#' @author CEPEL
#'
#'
#'
#' @export 
split_year_plot <- function(series, add_label=NULL, title="Title") {
  df <- data.frame(dates=as.Date(zoo::index(series)), 
                   values = as.numeric(series), 
                   year = factor(format(zoo::index(series), "%Y"), labels=paste(unique(format(zoo::index(series), "%Y")),add_label)))
  
  g <- ggplot2::ggplot(df, ggplot2::aes(x=dates, y=values)) + ggplot2::geom_line(size=1.2, color=("darkgrey"))+ ggplot2::geom_point(color="darkgreen") + ggplot2::facet_wrap(. ~ year, scales="free") + ggplot2::theme_light() + ggplot2::theme(strip.text=ggplot2::element_text(size=12), axis.title = ggplot2::element_blank()) + ggplot2::ggtitle(title)
  
  return(g)
}



#' @title Programa select_days	
#' @name select_days
#'
#' @description substitui select_days dsa
#' 
#' @param (x)
#' 
#' @details 
#'
#'
#' @return select_days
#'
#' @author CEPEL
#'
#'
#'
#' @export 
select_days <- function(x, Date="05-01", Format="%m-%d", Range=c(-2,2)) {
  dates <- zoo::index(x)
  selection <- dates[format(dates, Format)== Date]
  big_selection <- as.Date("2010-01-01")
  for (j in seq(from=Range[1], to=Range[2])) {
    big_selection <- c(big_selection, selection + j) }
  big_selection <- sort(big_selection[2:length(big_selection)])
  
  return(x[big_selection])
}



#' @title Programa get_weekdays	
#' @name get_weekdays
#'
#' @description substitui get_weekdays dsa
#' 
#' @param (x)
#' 
#' @details 
#'
#'
#' @return get_weekdays
#'
#' @author CEPEL
#'
#'
#'
#' @export 
get_weekdays <- function(series, Date="10-03", Format="%m-%d"){
  dates <- zoo::index(series)
  selection <- dates[format(dates, Format)== Date]
  weekdays(selection)
}


#' @title Programa drop31	
#' @name drop31
#'
#' @description substitui drop31 dsa
#' 
#' @param (x)
#' 
#' @details 
#'
#'
#' @return drop31
#'
#' @author CEPEL
#'
#'
#'
#' @export 
drop31<-function (x_ts, new_start = 335, new_end = 55) 
{
  a <- paste(expand.grid(1:31, 1:12, stats::start(x_ts)[1]:stats::end(x_ts)[1])$Var3, 
             ifelse(expand.grid(1:31, 1:12, stats::start(x_ts)[1]:stats::end(x_ts)[1])$Var2 < 
                      9.5, paste("0", expand.grid(1:31, 1:12, stats::start(x_ts)[1]:stats::end(x_ts)[1])$Var2, 
                                 sep = ""), expand.grid(1:31, 1:12, stats::start(x_ts)[1]:stats::end(x_ts)[1])$Var2), 
             ifelse(expand.grid(1:31, 1:12, stats::start(x_ts)[1]:stats::end(x_ts)[1])$Var1 < 
                      9.5, paste("0", expand.grid(1:31, 1:12, stats::start(x_ts)[1]:stats::end(x_ts)[1])$Var1, 
                                 sep = ""), expand.grid(1:31, 1:12, stats::start(x_ts)[1]:stats::end(x_ts)[1])$Var1), 
             sep = "-")
  
  ind=which((month(as.Date(a))==2)&(day(as.Date(a))==29))
  #if (length(ind)>1) a=a[-ind]
  st <- base::as.Date(paste(stats::start(x_ts)[1], new_start), 
                      format = "%Y %j")
  en <- base::as.Date(paste(stats::end(x_ts)[1], new_end), 
                      format = "%Y %j")
  fill_date <- a[grep(st, a):grep(en, a)]
  round <- 0
  while (length(x_ts) > length(fill_date) & round < 1000) {
    round <- round + 1
    en <- en + 1
    fill_date <- a[grep(st, a):grep(en, a)]
  }
  while (length(x_ts) < length(fill_date) & round < 1000) {
    round <- round + 1
    en <- en - 1
    fill_date <- a[grep(st, a):grep(en, a)]
  }
  b <- is.na(as.Date(fill_date))
  long_xts <- xts::xts(x_ts, order.by = zoo::na.locf(base::as.Date(fill_date)))
  long_xts <- long_xts[!b]
  long_xts
}



#' @title Programa carregaarquivos	
#' @name carregaarquivos
#'
#' @description ##### identifica os arquivos de entrada
#' 
#' @param (x)
#' 
#' @details 
#'
#'
#' @return carregaarquivos
#'
#' @author CEPEL
#'
#'
#'
#' @export 
carregaarquivos<-function(caminho){
  # MONTA AQUIVO PARAMETROS.CSV
  lista=list.files(caminho) #lista arquivos no diretorio
  narquivos=length(lista) # numero de arquivos
  saida=rep(" ",6) # inicializa vetor saida
  for (i in 1:narquivos) {     
    nomearquivo=tail(strsplit(lista[i],"_")[[1]],1)
    nomeserie=head(strsplit(lista[i],"_")[[1]],1)
    if (i==1) saida[1]=nomeserie
    nome=strsplit(lista[i],".csv")
    if (nomearquivo=="CARGAHIST.csv"){
      saida[2]=nome[[1]]
      nomeserie=head(strsplit(lista[i],"_")[[1]],1)
      saida[1]=nomeserie[[1]]		
    }
    if (nomearquivo=="TEMPHIST.csv") saida[3]=nome[[1]]
    if (nomearquivo=="FERIADOS.csv") saida[4]=nome[[1]]
    if (nomearquivo=="HORAVERAO.csv") saida[5]=nome[[1]]
    if (nomearquivo=="PERDAS.csv") saida[6]=nome[[1]]
    if (nomearquivo=="PRECIPITACAO.csv") saida[7]=nome[[1]]
    # if (nomearquivo=="SEPARADOR.csv") {
    # auxarquivo=paste(caminho,"/",lista[i],sep="")
    # aux=read.csv2(auxarquivo,header=T)
    # if (aux==",") saida[8]=as.character(",")
    # if (aux==".") saida[8]=as.character(".")
    # }
    arqcarga=paste0(saida[2],".csv")
    arqtemp=paste0(saida[3],".csv")
    arqferiado=paste0(saida[4],".csv")
    #arqverao=paste0(saida[5],".csv")
    arqabatimento=paste0(saida[6],".csv")
    arqprec=paste0(saida[7],".csv")
    
    
    # arqcarga=saida[2]
    # arqtemp=saida[3]
    # arqferiado=saida[4]
    # arqverao=saida[5]
  }
  
  prefixo=unlist(strsplit(arqcarga,"_"))[1]
  return(list(arqcarga=arqcarga,arqtemp=arqtemp,arqferiado=arqferiado,arqabatimento=arqabatimento,arqprec=arqprec))
}





